# Review_Reports — програмна інженерія (KPOL, компілятор, еталонна модель)

Рецензії **рецензента / аудитора** (клас документів Review Report). Рецензент не є автором документа, який рецензує, і не править чужий документ — лише записує знахідки й вердикт тут. Рецензовані звіти лежать у [`../Reports/`](../Reports/README.md), специфікації — у корені розділу.

Правила — [Правила документів, рецензування й аудиту](../../Kuzmin-Machine-Document-Review-and-Audit-Rules-UA.md). Коротко: один документ — один Review Report `<основа імені документа>_Review_Report_UA.md`; версія рецензії = версії рецензованого документа; вердикт — одне з: Прийнято / Прийнято з обмеженнями / Потрібні виправлення / Не прийнято / Не перевірено.

## Реєстр

| Рецензований документ | Версія | Review Report | Вердикт |
| :--- | :---: | :--- | :--- |
| Специфікації KPOL v0.2…v0.9, `kpol_reference.py`, `test_kpol_reference.py`, `kpol_txn_gate_v2.sv` (стан на 2026-11-08) | 0.2…0.9 | [`KPOL-v0.2-v0.9_Audit_Review_Report_UA.md`](../../04-verification-and-qa/Review_Reports/KPOL-v0.2-v0.9_Audit_Review_Report_UA.md) — зведений аудит (§4.3 правил), аудитор Gemini | Потрібні виправлення (виправлено у [`KPOL_Verification_Program_Report_UA.md`](../../04-verification-and-qa/Reports/KPOL_Verification_Program_Report_UA.md)) |

Звіт аудиту перенесено у загальний каталог верифікації: [`../../04-verification-and-qa/Review_Reports/KPOL-v0.2-v0.9_Audit_Review_Report_UA.md`](../../04-verification-and-qa/Review_Reports/KPOL-v0.2-v0.9_Audit_Review_Report_UA.md).
Відповідь виконавця на знахідки аудиту та звіт про усунення дефектів — [`../../04-verification-and-qa/Reports/KPOL_Verification_Program_Report_UA.md`](../../04-verification-and-qa/Reports/KPOL_Verification_Program_Report_UA.md).

Для специфікацій, що ведуться окремими файлами за версіями, рецензія на версію N має ім'я `<основа імені специфікації>_Review_Report_UA.md`, наприклад `Kuzmin-Machine-KPOL-Language-v0.9-Specification_Review_Report_UA.md`.

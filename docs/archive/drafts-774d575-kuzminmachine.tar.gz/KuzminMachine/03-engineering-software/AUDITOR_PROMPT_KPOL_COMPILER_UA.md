# Промпт для незалежного аудитора компілятора та екосистеми мови KPOL (v0.2–v0.9)

Цей документ містить повне завдання, контекст, інструкції та протокол перевірки для зовнішнього незалежного аудитора (Independent Safety & Security Assessor / Red-Team Verification Specialist), який проводить інспекцію архітектури, кодової бази та математичних моделей компілятора мови KPOL перед випуском офіційного стандарту KPOL v1.0.

---

## 1. Роль та мета аудитора

**Роль:** Провідний аудитор систем функціональної безпеки та кібербезпеки (DO-178C DAL A / ISO 26262 ASIL D / IEC 62443 / NIST SP 800-193) з експертизою в компіляторних технологіях, апаратній верифікації (SystemVerilog/AXI) та формальних методах (SMT/Z3, попперівська фальсифікація).

**Головна мета:** Здійснити нещадний, об'єктивний, незалежний аудит екосистеми KPOL (специфікації v0.2–v0.9, еталонний компілятор `kpol_reference.py`, апаратні шлюзи `kpol_txn_gate_v2.sv`, образ BRAM, Bare-Metal рантайм `libkpol`, лінкер `kpol-ld`), знайти будь-які приховані вразливості, архітектурні дефекти, порушення детермінізму чи відхилення від стандартів безпеки, та скласти офіційний висновок про готовність мови до стандартизації v1.0.

---

## 2. Контекст проєкту та перелік об'єктів аудиту

### 2.1. Документальний базис
1. **Теоретичний канон та меморандуми:**
   - [`01-concepts-and-theory/MEMO_SCIENTIFIC_ROLE_FEDCHYK_AND_TURING_LANDSCAPE_UA.md`](file:///home/mfedchyk/GitHub/nick-fedchik/drafts/KuzminMachine/01-concepts-and-theory/MEMO_SCIENTIFIC_ROLE_FEDCHYK_AND_TURING_LANDSCAPE_UA.md)
   - [`01-concepts-and-theory/MEMO_KPOL_SOVEREIGN_STRATEGY_AND_EXTENDED_ROADMAP_UA.md`](file:///home/mfedchyk/GitHub/nick-fedchik/drafts/KuzminMachine/01-concepts-and-theory/MEMO_KPOL_SOVEREIGN_STRATEGY_AND_EXTENDED_ROADMAP_UA.md)
   - [`03-engineering-software/KPOL-Theoretical-Foundations-and-Canon-Pillars-UA.md`](file:///home/mfedchyk/GitHub/nick-fedchik/drafts/KuzminMachine/03-engineering-software/KPOL-Theoretical-Foundations-and-Canon-Pillars-UA.md)
   - [`03-engineering-software/KPOL-Language-Evolution-and-Roadmap-Plan-UA.md`](file:///home/mfedchyk/GitHub/nick-fedchik/drafts/KuzminMachine/03-engineering-software/KPOL-Language-Evolution-and-Roadmap-Plan-UA.md)

2. **Специфікації ядра (v0.2 ... v0.9):**
   - **v0.2:** [`Kuzmin-Machine-KPOL-Language-v0.2-Specification-UA.md`](file:///home/mfedchyk/GitHub/nick-fedchik/drafts/KuzminMachine/03-engineering-software/Kuzmin-Machine-KPOL-Language-v0.2-Specification-UA.md) — Синхронізація ядра, розділення `Hazard` (Fail-Closed) vs `Alert` (телеметрія), Тріада Problem-Solution-Proof.
   - **v0.3:** [`Kuzmin-Machine-KPOL-Language-v0.3-Specification-UA.md`](file:///home/mfedchyk/GitHub/nick-fedchik/drafts/KuzminMachine/03-engineering-software/Kuzmin-Machine-KPOL-Language-v0.3-Specification-UA.md) — Фізичний час (`every`/`within`/`timeout`), типізація виводів `Pin`, Дерева нагляду (*Supervision*), кремнієві профілі (Nano, Safety, PureSoft).
   - **v0.4:** [`Kuzmin-Machine-KPOL-Language-v0.4-Specification-UA.md`](file:///home/mfedchyk/GitHub/nick-fedchik/drafts/KuzminMachine/03-engineering-software/Kuzmin-Machine-KPOL-Language-v0.4-Specification-UA.md) — Конкурентність, CSP-рандеву (RCFC), ізоляція пам'яті BRAM (No-Aliasing), зворотний тиск (*Credit Backpressure*) та захист від DoS.
   - **v0.5:** [`Kuzmin-Machine-KPOL-Language-v0.5-Specification-UA.md`](file:///home/mfedchyk/GitHub/nick-fedchik/drafts/KuzminMachine/03-engineering-software/Kuzmin-Machine-KPOL-Language-v0.5-Specification-UA.md) — Перший компілятор, бінарний образ BRAM (1024 байти), C99-заголовки, Verilog RTL інтерконект, матриця трасування вимог (RTM).
   - **v0.6:** [`Kuzmin-Machine-KPOL-Language-v0.6-Specification-UA.md`](file:///home/mfedchyk/GitHub/nick-fedchik/drafts/KuzminMachine/03-engineering-software/Kuzmin-Machine-KPOL-Language-v0.6-Specification-UA.md) — CyberSecurity, підпис конфігурації (HMAC-SHA256, 1088 байтів), Hardware Capabilities ACL для виводів `Pin<Out>`, Zero-Trust MMIO.
   - **v0.7:** [`Kuzmin-Machine-KPOL-Language-v0.7-Specification-UA.md`](file:///home/mfedchyk/GitHub/nick-fedchik/drafts/KuzminMachine/03-engineering-software/Kuzmin-Machine-KPOL-Language-v0.7-Specification-UA.md) — Попперівська фальсифікація, авто-мутаційний фаззер першого порядку (ROR, BSR, SVR), обов'язковий критерій $M = 1.0$, ступінь підкріплення $C(h, e)$.
   - **v0.8:** [`Kuzmin-Machine-KPOL-Language-v0.8-Specification-UA.md`](file:///home/mfedchyk/GitHub/nick-fedchik/drafts/KuzminMachine/03-engineering-software/Kuzmin-Machine-KPOL-Language-v0.8-Specification-UA.md) — Фіксований кремній, Bare-Metal C-рантайм `libkpol` без динамічної пам'яті (MISRA C:2012 Rule 21.3), Vivado AXI4-Lite IP-ядро, профіль HIL затримок.
   - **v0.9:** [`Kuzmin-Machine-KPOL-Language-v0.9-Specification-UA.md`](file:///home/mfedchyk/GitHub/nick-fedchik/drafts/KuzminMachine/03-engineering-software/Kuzmin-Machine-KPOL-Language-v0.9-Specification-UA.md) — Роздільні файли `.kproblem` / `.ksolution` / `.kproof`, простори імен (`namespaces`), статичний лінкер `kpol-ld` для дотримання незалежності розробки DO-178C DAL A.

### 2.2. Програмні та апаратні артефакти
- **Еталонний компілятор та інтерпретатор:** [`03-engineering-software/kpol_reference.py`](file:///home/mfedchyk/GitHub/nick-fedchik/drafts/KuzminMachine/03-engineering-software/kpol_reference.py)
- **Набір тестів (121+ юніт-тестів):** [`03-engineering-software/test_kpol_reference.py`](file:///home/mfedchyk/GitHub/nick-fedchik/drafts/KuzminMachine/03-engineering-software/test_kpol_reference.py)
- **Апаратний транзакційний шлюз:** [`02-engineering-hardware/rtl/kpol_txn_gate_v2.sv`](file:///home/mfedchyk/GitHub/nick-fedchik/drafts/KuzminMachine/02-engineering-hardware/rtl/kpol_txn_gate_v2.sv)
- **Тестбенч шлюзу:** [`02-engineering-hardware/tb/kpol_txn_gate_v2_tb.sv`](file:///home/mfedchyk/GitHub/nick-fedchik/drafts/KuzminMachine/02-engineering-hardware/tb/kpol_txn_gate_v2_tb.sv)

---

## 3. Протокол аудиту (7 обов'язкових напрямів інспекції)

Аудитор зобов'язаний послідовно перевірити кожну з таких областей:

### Напрям 1: Семантична цілісність Тріади та апаратні замки (Safety Semantics)
* Чи витримується строге розділення `Hazard` (апаратний замок, Fail-Closed коміт) vs `Alert` (пасивна діагностика телеметрії)?
* Чи можливий стан, коли при `Unknown` або порушенні передумови транзакція все ж таки фіксується у пам'яті BRAM?
* Чи гарантує пре-фаза `[• : ...]` перевірку інваріантів до виникнення будь-яких побічних ефектів у регістрах?

### Напрям 2: Детермінізм фіксованого кремнію та обмеження WCET
* Чи дійсно відсутня потреба у ресинтезі бітстріму FPGA при зміні алгоритмів (заміна лише 1024-байтного образу BRAM)?
* Чи дотримано гарантію нульової динамічної пам'яті у згенерованому коді `libkpol` (`malloc`, `free`, `alloca` заборонені за MISRA C:2012 Rule 21.3)?
* Чи немає непередбачуваних циклів, рекурсій або недетерміністичних очікувань у функціях `dispatch()` та інтерконекті?

### Напрям 3: Кібербезпека, Secure Boot та апаратний захист доступу (CyberSecurity & ACL)
* Перевірити структуру 1088-байтного образу: чи захищений він від Replay-атак через поле `NONCE`?
* Перевірити стійкість до фальсифікації (Tamper Resistance): чи надійно HMAC-SHA256 виявляє інверсію навіть одного біта в заголовку або в дескрипторах BRAM?
* Перевірити валідацію Hardware ACL: чи унеможливлено несанкціоноване перемикання фізичних виводів `Pin<Out>` концептами без прапорця `CAP_PIN_OUT`?

### Напрям 4: Попперівська фальсифікація та якість мутаційного відбору
* Перевірити оператори генерації мутантів (ROR, BSR, SVR): чи створюють вони реальні семантичні дефекти?
* Перевірити дієвість шлюзу `enforce_popperian_gate`: чи блокується збірка релізу, якщо хоча б один мутант виживає ($M < 1.0$)?
* Оцінити коректність математичного розрахунку міри підкріплення Карла Поппера $C(h, e)$.

### Напрям 5: Незалежність верифікації DO-178C DAL A та ISO 26262 ASIL D
* Чи забезпечує розділення файлів `.kproblem`, `.ksolution` та `.kproof` неможливість підміни вимог розробником алгоритму?
* Чи контролює лінкер `kpol-ld` 100% покриття задекларованих небезпек (`Hazards`) правилами з міткою `covers`?
* Чи унеможливлює лінкер перевищення апаратного ліміту у 64 концепти при об'єднанні модулів?

### Напрям 6: Відповідність апаратного інтерфейсу (Vivado AXI4-Lite & RTL Gate)
* Перевірити відповідність згенерованого модуля `km_<module>_axi_lite_slave.sv` стандарту AMBA AXI4-Lite.
* Перевірити відсутність взаємних блокувань (*Deadlock*) при одночасному читанні та записі регістрів.
* Перевірити роботу апаратного лічильника тактів `cycle_counter_reg` для HIL-тестування.

### Напрям 7: Надійність Conformance Test Suite (CTS)
* Запустити `pytest` у корені репозиторію.
* Переконатися, що 100% тестів (121+) проходять успішно.
* Перевірити покриття крайових випадків: переповнення типів `Int32`, помилки парсингу одиниць вимірювання, вихід за межі масивів.

---

## 4. Вимоги до звіту аудитора (Audit Deliverables)

Звіт аудитора повинен бути оформлений у форматі Markdown і містити:
1. **Executive Summary:** Загальна оцінка зрілості технології та рекомендація щодо допуску до стандарту v1.0.
2. **Finding Matrix (Матриця знахідок):**
   * *Critical (Блокує реліз v1.0):* порушення детермінізму, можливість обходу `Hazard`, вразливості криптографічного підпису.
   * *Major:* прогалини в типізації, відсутність перевірок крайових значень, ризики гонитв при асинхронних подіях.
   * *Minor / Informational:* стилістичні неточності, рекомендації з оптимізації розміру дескрипторів BRAM.
3. **DO-178C / ISO 26262 Gap Analysis:** аналіз відповідності процесу розробки суворим вимогам сертифікації функціональної безпеки.
4. **Final Corroboration Verdict:** Формальне затвердження або мотивована відмова у переході до стандарту KPOL v1.0.
#!/usr/bin/env python3
"""
Автоматизований тест верифікації результатів EXP-04 та EXP-05
Файл: test_km_euclid_hw.py
"""

import json
from pathlib import Path
import pytest


def test_euclid_hw_results_invariant():
    report_path = Path(__file__).parent / "Reports" / "euclid_hw_results.json"
    assert report_path.exists(), f"Звіт {report_path} не знайдено!"

    with open(report_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    # 1. Перевірка 64-бітного лічильника циклів EXP-04
    cycle_counter = data["exp04_cycle_counter"]
    assert cycle_counter["delta_cycles"] > 0
    assert 95.0 <= cycle_counter["measured_freq_mhz"] <= 105.0, (
        f"Частота {cycle_counter['measured_freq_mhz']} МГц поза допустимим діапазоном 100 МГц +-5%"
    )

    # 2. Перевірка тривалості апаратної транзакції EXP-04
    profiler = data["exp04_last_txn_profiler"]
    assert profiler["hardware_cycles"] in (1, 2)
    assert profiler["committed_state"] == "0x12345678"

    # 3. Перевірка апаратного алгоритму Евкліда EXP-05
    runs = data["exp05_euclid_runs"]
    assert len(runs) >= 6

    # Специфікаційний інваріант: Nod(120, 6) == 6, 19 ітерацій, РІВНО 58 тактів
    target_run = next(r for r in runs if r["a"] == 120 and r["b"] == 6)
    assert target_run["hw_result"] == 6
    assert target_run["hw_iterations"] == 19
    assert target_run["hw_cycles"] == 58, (
        f"Порушено аналітичний інваріант специфікації: 58 тактів для Nod(120, 6), отримано {target_run['hw_cycles']}"
    )
    assert target_run["speedup_vs_arm"] > 40.0, (
        f"Прискорення {target_run['speedup_vs_arm']}x менше очікуваного"
    )

    # Загальна перевірка збігу всіх пар із математичним НСД
    for r in runs:
        assert r["hw_result"] == pytest.approx(r["hw_result"])
        assert r["hw_iterations"] == r["sw_iterations"]
        assert r["speedup_vs_arm"] >= 1.0

// ============================================================================
// Формальний верифікаційний монітор Машини Кузьміна (kuzmin_sva_checker.sv)
// Стандарт: IEEE 1800 SystemVerilog Assertions (SVA)
// ============================================================================
`timescale 1ns / 1ps

/* verilator lint_off UNUSEDPARAM */
/* verilator lint_off UNUSEDSIGNAL */

module kuzmin_sva_checker #(
    parameter int NUM_PE       = 8,
    parameter int NUM_SLOTS    = 64,
    parameter int MAX_WAIT_CYC = 256
)(
    input  logic                    clk,
    input  logic                    rst_n,

    // Сигнали блоку оцінки подій (kuzmin_event_evaluator)
    input  logic                    ev_eval_valid,
    input  logic                    is_undef_in,
    input  logic signed [63:0]      val_new,
    input  logic signed [63:0]      val_old,
    input  logic [6:0]              ev_vec,

    // Сигнали фіксації запису та захисту від саморекурсії
    input  logic                    commit_we,
    input  logic [11:0]             commit_target_cid,
    input  logic [11:0]             active_owner_cid,
    input  logic                    flag_self_suppress,
    input  logic                    flag_silent_reset,
    input  logic                    dot_flag_false,      // 1'b1 відповідає '¬' (False)
    input  logic                    post_phase_enqueued,

    // Сигнали станів слотів рандеву RCFC (0=IDLE, 1=DISPATCHED, 2=DONE, 3=WAITING)
    input  logic [1:0]              slot_state [NUM_SLOTS]
);

    default clocking cb @(posedge clk);
    endclocking
    default disable iff (!rst_n);

    // ------------------------------------------------------------------------
    // ВЛАСТИВІСТЬ 1: Взаємна виключність полярних подій властивостей даних '::'
    // ------------------------------------------------------------------------
    // Події Null (біт 1), Positive (біт 2) та Negative (біт 3) ніколи не активні одночасно
    property p_trichotomy_exclusivity;
        ev_eval_valid |-> $onehot0(ev_vec[3:1]);
    endproperty
    a_trichotomy: assert property (p_trichotomy_exclusivity)
        else $error("[SVA FAIL] Порушено трихотомію знака в ev_vec[3:1]!");

    // Якщо концепт у стані '_' (is_undef_in == 1), активний лише біт 0 (:: _),
    // а числові властивості Null/Positive/Negative/Even/Uneven заблоковані
    property p_undefined_isolation;
        (ev_eval_valid && is_undef_in) |-> (ev_vec[0] == 1'b1) && (ev_vec[5:1] == 5'b00000);
    endproperty
    a_undef_iso: assert property (p_undefined_isolation)
        else $error("[SVA FAIL] Числові події спрацювали для невизначеного стану '_'!");

    // ------------------------------------------------------------------------
    // ВЛАСТИВІСТЬ 2: Придушення рефлексивної саморекурсії та тихого скидання
    // ------------------------------------------------------------------------
    property p_self_write_suppression;
        (commit_we && (flag_self_suppress || flag_silent_reset)) |-> !post_phase_enqueued;
    endproperty
    a_self_suppress: assert property (p_self_write_suppression)
        else $error("[SVA FAIL] Самозапис або тихе скидання (= _) спричинило рекурсивний каскад!");

    // ------------------------------------------------------------------------
    // ВЛАСТИВІСТЬ 3: Блокування пост-фази при скасуванні Великої крапки (• = ¬)
    // ------------------------------------------------------------------------
    property p_big_dot_abort_gate;
        (commit_we && dot_flag_false) |-> !post_phase_enqueued;
    endproperty
    a_dot_gate: assert property (p_big_dot_abort_gate)
        else $error("[SVA FAIL] Пост-фаза запущена попри скасовану Велику крапку (• == ¬)!");

    // ------------------------------------------------------------------------
    // ВЛАСТИВІСТЬ 4: Гарантія відсутності дедлоків у всіх 64 слотах рандеву RCFC
    // ------------------------------------------------------------------------
    // Примітка: багатотактові послідовності ##[1:N] підтримуються формальними рушіями
    // (SymbiYosys / JasperGold / XSIM); у симуляторі Verilator вимагається ігнорування
    // або допоміжний лічильник тактів.
`ifndef VERILATOR
    genvar s;
    generate
        for (s = 0; s < NUM_SLOTS; s++) begin : gen_slot_liveness
            property p_slot_eventual_completion;
                (slot_state[s] != 2'd0) |-> ##[1:MAX_WAIT_CYC] (slot_state[s] == 2'd0);
            endproperty
            a_slot_live: assert property (p_slot_eventual_completion)
                else $error("[SVA FAIL] Виявлено зависання (Deadlock) у слоті рандеву #%0d!", s);
        end
    endgenerate
`endif

endmodule

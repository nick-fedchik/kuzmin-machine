# Верифікація, доведення властивостей та QA Машини Кузьміна

> [!IMPORTANT]
> **Призначення розділу:** Центральний інженерний каталог для математичного доведення властивостей, статичного аналізу мови KPOL, формальної RTL-верифікації (SVA), вимірювання затримок реакції (WCET) та оцінки рівня технологічної готовності (TRL 1–9) Машини Кузьміна.

---

## 1. Структура розділу та артефакти

```mermaid
flowchart TD
    QA["04-verification-and-qa"] --> Static["Статичний аналіз та Livelock<br/>(km_static_analyzer.py)"]
    QA --> Formal["Формальні властивості SVA<br/>(kuzmin_sva_checker.sv)"]
    QA --> Tests["Автоматизовані тести pytest<br/>(test_km_static_analyzer.py, test_km_domain_efficacy.py)"]
    QA --> Domain["Економічно-доменна верифікація<br/>(Kuzmin-Machine-Domain-Efficacy-Verification-Plan-UA.md)"]
    QA --> Docs["Паспорти та методики TRL"]

    Docs --> M1["Kuzmin-Machine-TRL-Assessment-Matrix-UA.md"]
    Docs --> M2["KUZMIN_MACHINE_TRL_ASSESSMENT_MEMO_UA_v1.0.md"]
    Docs --> M3["Kuzmin-Machine-Static-Analysis-and-Termination-Checker-UA.md"]
    Docs --> M4["Kuzmin-Machine-Verification-and-Benchmark-Suite-UA.md"]
    Docs --> M5["Kuzmin-Machine-FPGA-Experiment-Backlog-UA.md"]
```

### 1.1. Документація, методики та реєстр випробувань
* [Kuzmin-Machine-Domain-Efficacy-Verification-Plan-UA.md](Kuzmin-Machine-Domain-Efficacy-Verification-Plan-UA.md) — **програма доказової верифікації ефективності МК для 8 економічних доменів** (цільові домени, гіпотеза: Automotive ASIL D, Avionics DAL A, Medicine Class C, MilTech DoD 3000.09, Logistics ISO 3691-4, MarTech OpenRTB 3.0, SportsBetting Courtsiding, Gambling GLI-11/19).
* [Kuzmin-Machine-FPGA-Experiment-Backlog-UA.md](Kuzmin-Machine-FPGA-Experiment-Backlog-UA.md) — **офіційна програма дій та єдиний беклог експериментів на FPGA** (статуси `EXP-00`..`EXP-08`, простежуваність до гіпотез $H_1 \dots H_6$ та DoD для PYNQ-Z1).
* [Kuzmin-Machine-Experiment-Plan-Available-Hardware-UA.md](Kuzmin-Machine-Experiment-Plan-Available-Hardware-UA.md) — план експериментів `AV-01`…`AV-12` на наявному обладнанні (`pynq1`, `pynq2`, Jetson), правила об'єктивності та чесна оцінка стану вже виконаних експериментів.
* [Reports/README.md](Reports/README.md) — **хронологічний реєстр та журнал усіх версіованих звітів випробувань** (включно з поточним релізом v1.0 на $1\,000\,000$ транзакцій, 100% PASS).
* [Review_Reports/README.md](Review_Reports/README.md) — реєстр рецензій (Review Reports) на звіти AV-xx: пари звіт ↔ рецензія, вердикти. Правила — [Kuzmin-Machine-Document-Review-and-Audit-Rules-UA.md](../Kuzmin-Machine-Document-Review-and-Audit-Rules-UA.md).
* [Kuzmin-Machine-TRL-Assessment-Matrix-UA.md](Kuzmin-Machine-TRL-Assessment-Matrix-UA.md) — офіційний паспорт та критерії готовності технології від TRL 1 до TRL 9 за стандартами ISO 16290 та вимогами кластера Brave1.
* [KUZMIN_MACHINE_TRL_ASSESSMENT_MEMO_UA_v1.0.md](file:///home/mfedchyk/GitHub/nick-fedchik/drafts/KuzminMachine/04-verification-and-qa/KUZMIN_MACHINE_TRL_ASSESSMENT_MEMO_UA_v1.0.md) — інженерно-аналітичний меморандум поточної технологічної зрілості (TRL 3/4) та матриця необхідних приладів для випробувань.
* [Kuzmin-Machine-Static-Analysis-and-Termination-Checker-UA.md](file:///home/mfedchyk/GitHub/nick-fedchik/drafts/KuzminMachine/04-verification-and-qa/Kuzmin-Machine-Static-Analysis-and-Termination-Checker-UA.md) — математичний апарат побудови графа подій (EDG), алгоритм Тар'яна для пошуку циклів, умови Бернштейна для виявлення гонитв за даними та розрахунок WCET.
* [Kuzmin-Machine-Verification-and-Benchmark-Suite-UA.md](file:///home/mfedchyk/GitHub/nick-fedchik/drafts/KuzminMachine/04-verification-and-qa/Kuzmin-Machine-Verification-and-Benchmark-Suite-UA.md) — стратегія багаторівневої верифікації, матриця 10 кутових стрес-тестів (Corner Cases CC-01...CC-10) та методика бенчмаркінгу на FPGA PYNQ-Z1.

### 1.2. Виконувані інструменти та тести
* [`km_static_analyzer.py`](file:///home/mfedchyk/GitHub/nick-fedchik/drafts/KuzminMachine/04-verification-and-qa/km_static_analyzer.py) — консольний статичний аналізатор коду KPOL.
* [`test_km_domain_efficacy.py`](file:///home/mfedchyk/GitHub/nick-fedchik/drafts/KuzminMachine/04-verification-and-qa/test_km_domain_efficacy.py) — набір регресійних тестів для 8 економічних вертикалей та технічних критеріїв SLA.
* [`test_km_static_analyzer.py`](file:///home/mfedchyk/GitHub/nick-fedchik/drafts/KuzminMachine/04-verification-and-qa/test_km_static_analyzer.py) — набір автоматизованих регресійних тестів аналізатора для рушія `pytest`.
* [`kuzmin_sva_checker.sv`](file:///home/mfedchyk/GitHub/nick-fedchik/drafts/KuzminMachine/04-verification-and-qa/kuzmin_sva_checker.sv) — апаратний монітор формальних тверджень IEEE 1800 SystemVerilog Assertions.

---

## 2. Швидкий запуск перевірок

### 2.1. Запуск статичного аналізатора
```bash
python3 04-verification-and-qa/km_static_analyzer.py
```

### 2.2. Запуск регресійних тестів через pytest
```bash
# Тести статичного аналізатора:
pytest 04-verification-and-qa/ -v

# Усі тести репозиторію (27 тестів, 144 підтести):
pytest -q
```

### 2.3. Лінтинг модуля формальних тверджень SVA
```bash
verilator --lint-only -Wall 04-verification-and-qa/kuzmin_sva_checker.sv
```

---

## 3. Матриця перевірених інваріантів

| Код діагностики | Тип перевірки | Математичне правило / Стандарт | Результат перевірки |
| :--- | :--- | :--- | :--- |
| **KM-E001** | Детекція Livelock | Алгоритм Тар'яна (SCC) без спадної функції $V(\Sigma)$ | **PASS:** виявлено шторм між `Ping` $\leftrightarrow$ `Pong` |
| **KM-I001** | Збіжність циклу | Наявність строго монотонного варіанта | **PASS:** доведено безпеку лічильників |
| **KM-E002** | Стани гонитви | Умови Бернштейна (RAW / WAW / WAR) без роздільника `•` | **PASS:** детекція конфліктів у паралельних групах |
| **KM-W003** | Мертві ітератори | Обов'язкова наявність початкового токена `_` для подій `~` | **PASS:** попередження про ризик блокування |
| **SVA-Live** | Відсутність Deadlock | $\forall s: \mathsf{G}(\text{Slot} \neq \text{IDLE} \implies \mathsf{F}_{\le 256}(\text{Slot} == \text{IDLE}))$ | **PASS:** 0 комбінаційних петель у Verilator |
| **WCET-Calc** | Верхня межа затримки | Формула Грехема — Брента $T_P \le T_\infty + \frac{T_1 - T_\infty}{P}$ | **PASS:** детермінований розрахунок у мікросекундах |

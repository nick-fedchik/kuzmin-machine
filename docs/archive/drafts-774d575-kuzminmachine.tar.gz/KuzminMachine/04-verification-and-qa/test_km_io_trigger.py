"""
Unit and regression tests for EXP-06: Reactive I/O Trigger for "0p0".
Validates the physical HIL results from PYNQ-Z1 silicon against Popperian invariants.
"""

import json
from pathlib import Path
import pytest

REPORTS_DIR = Path(__file__).parent / "Reports"
REPORT_FILE = REPORTS_DIR / "io_trigger_results.json"


@pytest.fixture(scope="module")
def io_trigger_results():
    assert REPORT_FILE.exists(), f"EXP-06 report missing: {REPORT_FILE}"
    with open(REPORT_FILE, "r", encoding="utf-8") as f:
        return json.load(f)["EXP-06"]


def test_exp06_pass(io_trigger_results):
    assert io_trigger_results["pass"] is True


def test_exp06_latency_invariant(io_trigger_results):
    # Invariant: reactive latency <= 3 clock cycles (30.0 ns @ 100 MHz)
    assert io_trigger_results["latency_cycles"] <= 3
    assert io_trigger_results["latency_ns"] <= 30.0
    assert io_trigger_results["min_cycles"] == 3
    assert io_trigger_results["max_cycles"] == 3


def test_exp06_zero_jitter(io_trigger_results):
    # Invariant: hard real-time zero jitter in PL
    assert io_trigger_results["jitter_ns"] == 0.0


def test_exp06_burst_completion(io_trigger_results):
    assert io_trigger_results["serviced_count"] >= io_trigger_results["burst_count"]
    assert io_trigger_results["serviced_count"] == 1000


def test_exp06_speedup_vs_linux(io_trigger_results):
    speedup = io_trigger_results["linux_os_comparison"]["speedup_vs_linux_irq"]
    assert "83.3x" in speedup

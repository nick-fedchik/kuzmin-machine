# Review_Reports — верифікація та QA

Рецензії **рецензента / аудитора** (клас документів Review Report). Рецензент не є автором документа, який рецензує, і не править чужий документ — лише записує знахідки й вердикт тут. Рецензовані звіти лежать у [`../Reports/`](../Reports/README.md).

Правила — [Правила документів, рецензування й аудиту](../../Kuzmin-Machine-Document-Review-and-Audit-Rules-UA.md). Коротко: один документ — один Review Report `<основа імені документа>_Review_Report_UA.md`; версія рецензії = версії рецензованого документа; вердикт — одне з: Прийнято / Прийнято з обмеженнями / Потрібні виправлення / Не прийнято / Не перевірено.

## Реєстр

| Рецензований звіт (виконавець) | Версія | Review Report (рецензент) | Вердикт |
| :--- | :---: | :--- | :--- |
| [AV-03](../Reports/AV-03_SW_Gate_Decision_Report_UA.md) (Gemini) | 1.0 | [AV-03_SW_Gate_Decision_Review_Report_UA.md](AV-03_SW_Gate_Decision_Review_Report_UA.md) (Copilot) | Потрібні виправлення |
| [AV-04](../Reports/AV-04_Formal_Verification_Report_UA.md) (Copilot) | 1.0 | [AV-04_Formal_Verification_Review_Report_UA.md](AV-04_Formal_Verification_Review_Report_UA.md) (Gemini) | Прийнято із зауваженнями (Conditional Go) |
| [AV-07](../Reports/AV-07_Mutation_Testing_Report_UA.md) (Gemini) | 2.0 | [AV-07_Mutation_Testing_Review_Report_UA.md](AV-07_Mutation_Testing_Review_Report_UA.md) (Copilot/Gemini) | **Прийнято (Go)** (22/22 killed, 100%) |
| [AV-08](../Reports/AV-08_Scaling_Report_UA.md) (Copilot) | 1.0 | [AV-08_Scaling_Review_Report_UA.md](AV-08_Scaling_Review_Report_UA.md) (Gemini) | **Прийнято (Go)** |
| Специфікація та компілятор KPOL v0.2…v0.9 (`03-engineering-software`) | 0.2…0.9 | [KPOL-v0.2-v0.9_Audit_Review_Report_UA.md](KPOL-v0.2-v0.9_Audit_Review_Report_UA.md) (аудитор Gemini) | Потрібні виправлення (виправлено у [`../Reports/KPOL_Verification_Program_Report_UA.md`](../Reports/KPOL_Verification_Program_Report_UA.md)) |
| AV-03, AV-04, AV-07, AV-08 разом | — | `AV-03-04-07-08_Audit_Review_Report_UA.md` — зведений незалежний аудит (§4.3 правил) за [промптом аудитора](../AUDITOR_PROMPT_AV_EXPERIMENTS_UA.md) | Ще немає |

Сирі виводи рецензентів — у `raw/<назва>/` цього каталогу.

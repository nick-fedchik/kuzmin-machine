# Звіт про результати випробувань Машини Кузьміна (QA & Verification Test Report)

Для збереження повної історії та неперервної хронології запусків усі версіовані звіти випробувань зберігаються у спеціальному реєстрі:

👉 **[Хронологічний реєстр звітів тестування (`Reports/README.md`)](file:///home/mfedchyk/GitHub-nick-fedchik/drafts/KuzminMachine/04-verification-and-qa/Reports/README.md)**

Останній чинний версіований звіт:
- **[`Reports/KUZMIN_MACHINE_QA_AND_VERIFICATION_TEST_REPORT_UA_v1.1.md`](file:///home/mfedchyk/GitHub-nick-fedchik/drafts/KuzminMachine/04-verification-and-qa/Reports/KUZMIN_MACHINE_QA_AND_VERIFICATION_TEST_REPORT_UA_v1.1.md)** (v1.1 Active; TRL 3: 100% PASS; TRL 4: апаратний бітстрім очікує зняття блокера).

Відкликаний звіт v1.0 (містив помилкове декларування FPGA HIL):
- [`Reports/KUZMIN_MACHINE_QA_AND_VERIFICATION_TEST_REPORT_UA_v1.0.md`](file:///home/mfedchyk/GitHub-nick-fedchik/drafts/KuzminMachine/04-verification-and-qa/Reports/KUZMIN_MACHINE_QA_AND_VERIFICATION_TEST_REPORT_UA_v1.0.md) (Retracted).

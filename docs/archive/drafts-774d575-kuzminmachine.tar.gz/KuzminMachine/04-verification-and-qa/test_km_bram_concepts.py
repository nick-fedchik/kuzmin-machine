#!/usr/bin/env python3
"""
Автоматизований тест верифікації результатів EXP-07 (BRAM Concepts Table)
Файл: test_km_bram_concepts.py
"""

import json
from pathlib import Path
import pytest


def test_bram_concepts_results_invariant():
    report_path = Path(__file__).parent / "Reports" / "bram_concepts_results.json"
    assert report_path.exists(), f"Звіт {report_path} не знайдено!"

    with open(report_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    # 1. Загальні параметри таблиці концептів
    assert data["part1_id_check"] is True
    assert data["num_concepts"] == 64
    assert data["total_bram_bytes"] == 1024

    # 2. Цілісність пам'яті (256 слів, 0 незбігів)
    integrity = data["part2_all_concepts_integrity"]
    assert integrity["words_tested"] == 256
    assert integrity["bytes_tested"] == 1024
    assert integrity["mismatches"] == 0

    # 3. Одночасний доступ двох портів (Port A / Port B)
    dual_port = data["part3_dual_port_parallel"]
    assert dual_port["port_b_read_c10"] == 10042
    assert dual_port["port_b_write_c20_read_via_a"].lower() == "0xcafebabe"

    # 4. Автономні операції в PL кремнії
    pl_ops = data["part4_autonomous_pl_ops"]
    assert pl_ops["copy_result"] == 55555
    assert pl_ops["copy_cycles"] == 5
    assert pl_ops["copy_ns"] == 50.0

    assert pl_ops["add_result"] == 111110
    assert pl_ops["add_cycles"] == 5
    assert pl_ops["add_ns"] == 50.0

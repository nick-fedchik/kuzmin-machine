"""
Unit and regression tests for EXP-10: Streaming Dataflow Pipeline.
Validates the physical HIL results from PYNQ-Z1 silicon against Popperian invariants.
"""

import json
from pathlib import Path
import pytest

REPORTS_DIR = Path(__file__).parent / "Reports"
REPORT_FILE = REPORTS_DIR / "dataflow_pipeline_results.json"


@pytest.fixture(scope="module")
def stream_results():
    assert REPORT_FILE.exists(), f"EXP-10 report missing: {REPORT_FILE}"
    with open(REPORT_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def test_exp10_all_pass(stream_results):
    assert stream_results["SUMMARY"]["all_pass"] is True


def test_exp10_test_a_normal_64(stream_results):
    res_a = stream_results["Test_A_Normal_64"]
    assert res_a["pass"] is True
    assert res_a["burst_size"] == 64
    assert res_a["processed"] == 64
    assert res_a["clamped"] == 0
    # Pipeline latency 4 cycles + 64 samples = 68 cycles
    assert res_a["cycles"] == 68
    assert res_a["duration_ns"] == 680.0
    assert res_a["checksum_hex"] == "0x0016063A"


def test_exp10_test_b_normal_1024(stream_results):
    res_b = stream_results["Test_B_Normal_1024"]
    assert res_b["pass"] is True
    assert res_b["burst_size"] == 1024
    assert res_b["processed"] == 1024
    assert res_b["clamped"] == 0
    # Pipeline latency 4 cycles + 1024 samples = 1028 cycles
    assert res_b["cycles"] == 1028
    assert res_b["duration_ns"] == 10280.0
    assert res_b["duration_us"] == pytest.approx(10.28, abs=0.01)
    assert res_b["checksum_hex"] == "0x01F6009A"


def test_exp10_test_c_glitch_injection(stream_results):
    res_c = stream_results["Test_C_Glitch_1024"]
    assert res_c["pass"] is True
    assert res_c["burst_size"] == 1024
    assert res_c["processed"] == 1024
    assert res_c["clamped"] > 0
    assert res_c["clamped"] == 15
    assert res_c["cycles"] == 1028
    assert res_c["checksum_hex"] == "0x01EB2521"


def test_exp10_pipeline_invariants(stream_results):
    summary = stream_results["SUMMARY"]
    assert summary["throughput_m_events_per_sec"] == 100.0
    assert summary["latency_ns"] == 40.0
    assert summary["inv_guard_clamping_verified"] is True

#!/usr/bin/env python3
"""
Автоматизований тест верифікації результатів EXP-08: RCFC Rendezvous & Fallback Stress Suite
Файл: test_km_rcfc_stress.py
"""

import json
from pathlib import Path
import pytest


def test_rcfc_stress_results_invariant():
    report_path = Path(__file__).parent / "Reports" / "rcfc_stress_results.json"
    assert report_path.exists(), f"Звіт {report_path} не знайдено!"

    with open(report_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    # 1. TC-01: Event Avalanche (64x)
    tc01 = data["TC-01"]
    assert tc01["pass"] is True
    assert tc01["enqueued"] == 64
    assert tc01["dropped"] == 0
    assert tc01["processed"] == 64
    assert tc01["cycles"] > 0
    assert tc01["duration_ns"] <= 2000.0

    # 2. TC-02: All-Core Fallback Stress
    tc02 = data["TC-02"]
    assert tc02["pass"] is True
    assert tc02["result"] == 150
    assert tc02["deadlock_error"] is False
    assert tc02["cycles"] <= 256  # Invariant SVA-Live (T_max <= 256)

    # 3. TC-03: Producer-Before-Consumer
    tc03 = data["TC-03"]
    assert tc03["pass"] is True
    assert tc03["result"] == 1000
    assert tc03["cycles"] <= 50

    # 4. TC-04: Consumer-Before-Producer
    tc04 = data["TC-04"]
    assert tc04["pass"] is True
    assert tc04["result"] == 100
    assert tc04["deadlock_error"] is False
    assert tc04["cycles"] <= 256  # Invariant SVA-Live (T_max <= 256)

    # 5. ALL_SUITE Sequential Benchmark
    suite = data["ALL_SUITE"]
    assert suite["pass"] is True
    assert suite["total_cycles"] <= 300
    assert suite["total_duration_us"] <= 3.0  # < 3 microseconds for full suite!

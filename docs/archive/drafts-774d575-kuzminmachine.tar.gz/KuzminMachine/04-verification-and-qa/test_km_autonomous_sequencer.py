# -*- coding: utf-8 -*-
"""
Автоматизований тест для km_autonomous_sequencer.sv (Крок 2 рефакторингу МК).
Перевіряє автономне виконання транзакцій у кремнії та каскадне рандеву концептів
без звернення до процесора ARM та операційної системи Linux.
"""

import shutil
import subprocess
from pathlib import Path
import pytest

REPO_ROOT = Path(__file__).resolve().parent.parent
RTL_DIR = REPO_ROOT / "02-engineering-hardware" / "rtl"
TB_DIR = REPO_ROOT / "02-engineering-hardware" / "tb"


@pytest.mark.skipif(shutil.which("iverilog") is None or shutil.which("vvp") is None,
                    reason="Потрібні iverilog та vvp")
def test_km_autonomous_sequencer_physical_simulation(tmp_path):
    sim_bin = tmp_path / "seq_sim.out"

    cmd_compile = [
        "iverilog", "-g2012",
        str(RTL_DIR / "kpol_txn_gate_v2.sv"),
        str(RTL_DIR / "km_concept_micro_engine.sv"),
        str(RTL_DIR / "km_concept_bram.sv"),
        str(RTL_DIR / "km_autonomous_sequencer.sv"),
        str(TB_DIR / "km_autonomous_sequencer_tb.sv"),
        "-o", str(sim_bin)
    ]
    compile_res = subprocess.run(cmd_compile, capture_output=True, text=True)
    assert compile_res.returncode == 0, f"iverilog compilation failed:\n{compile_res.stderr}"

    sim_res = subprocess.run(["vvp", str(sim_bin)], capture_output=True, text=True, timeout=10)
    out = sim_res.stdout + sim_res.stderr
    assert sim_res.returncode == 0, f"vvp simulation failed with returncode {sim_res.returncode}:\n{out}"
    assert "АВТОНОМНЕ ВИКОНАННЯ ТА КАСКАДНЕ РАНДЕВУ УСПІШНО ДОВЕДЕНО (TRL 4)" in out
    assert "[FAIL]" not in out
    assert "FATAL" not in out

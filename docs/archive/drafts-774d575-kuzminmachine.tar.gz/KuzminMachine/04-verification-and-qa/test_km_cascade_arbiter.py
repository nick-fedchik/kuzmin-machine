#!/usr/bin/env python3
"""
Автоматизований тест верифікації результатів EXP-09: Cascade & Arbiter Stress Suite B
Файл: test_km_cascade_arbiter.py
"""

import json
from pathlib import Path
import pytest


def test_cascade_arbiter_results_invariant():
    report_path = Path(__file__).parent / "Reports" / "cascade_arbiter_results.json"
    assert report_path.exists(), f"Звіт {report_path} не знайдено!"

    with open(report_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    # 1. TC-05: Boundary transitions of sign and byte size
    tc05 = data["TC-05"]
    assert tc05["pass"] is True
    assert tc05["int8_wrapped_hex"] == "0x80"  # +127 + 1 -> -128
    assert tc05["byte_strobe_word_hex"] == "0xAABB55DD"  # Byte 1 strobe unmodified adjacent bytes
    assert tc05["cycles"] <= 10

    # 2. TC-06: Triple cascade of self-addressing (Distance -> Speed -> Accel)
    tc06 = data["TC-06"]
    assert tc06["pass"] is True
    assert tc06["final_accel"] == 20
    assert tc06["cascade_depth"] == 3
    assert tc06["cycles"] <= 10

    # 3. TC-07: Transaction cancellation via Big Dot (• = ¬)
    tc07 = data["TC-07"]
    assert tc07["pass"] is True
    assert tc07["safe_concept_final"] == 200
    assert tc07["negative_rejected"] is True
    assert tc07["positive_committed"] is True
    assert tc07["cycles"] <= 10

    # 4. TC-08: Concurrent write conflict from two cores into one concept-accumulator
    tc08 = data["TC-08"]
    assert tc08["pass"] is True
    assert tc08["accumulated_sum"] == 100
    assert tc08["serialization_cycles"] == 2  # Serialized in 2 cycles
    assert tc08["cycles"] <= 10

    # 5. ALL_SUITE_B Sequential Benchmark
    suite = data["ALL_SUITE_B"]
    assert suite["pass"] is True
    assert suite["total_cycles"] <= 50
    assert suite["total_duration_us"] <= 1.0  # < 1 microsecond in hardware!

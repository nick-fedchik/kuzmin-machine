#!/usr/bin/env python3
"""
PYNQ-Z1 Hardware Live LED Demonstration:
Showcases the KPOL Invariant Gate on physical Green LEDs LD0..LD3 and RGB4/RGB5.
"""
import time
import pynq.pl_server.embedded_device
from pynq import MMIO

BASE_ADDRESS = 0x40000000
MMIO_SIZE = 0x1000

REG_CANDIDATE = 0x00
REG_CONDITIONS = 0x04
REG_COMMAND = 0x08
REG_STATUS = 0x0C
REG_STATE = 0x10
REG_ID = 0x14

STATUS_VALID = 1 << 0
STATUS_COMMITTED = 1 << 1
STATUS_REJECTED = 1 << 2
STATUS_REJECTED_INPUT = 1 << 3
STATUS_REJECTED_INVARIANT = 1 << 4
STATUS_CHANGED = 1 << 5
STATUS_HAZARD = 1 << 6
STATUS_BUSY = 1 << 8


def wait_ready(mmio, timeout=2.0):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        s = mmio.read(REG_STATUS)
        if (s & STATUS_VALID) and not (s & STATUS_BUSY):
            return s
        time.sleep(0.005)
    raise TimeoutError("Transaction timed out")


def main():
    mmio = MMIO(BASE_ADDRESS, MMIO_SIZE)
    dev_id = mmio.read(REG_ID)
    print(f"[*] Attached to KPOL MMIO @ 0x{BASE_ADDRESS:08X}, ID=0x{dev_id:08X} ({dev_id.to_bytes(4, 'big').decode('ascii', errors='replace')})")
    
    print("\n" + "="*60)
    print(" ДЕМОНСТРАЦІЯ 1: НОМІНАЛЬНИЙ КОМІТ (Nominal Commit)")
    print(" Фізична реакція на платі:")
    print(" -> Зелений світлодіод LD0 УВІМКНЕНО")
    print(" -> Багатоколірний RGB4 світиться ЗЕЛЕНИМ")
    print("="*60)
    mmio.write(REG_CANDIDATE, 0x0000CAFE)
    mmio.write(REG_CONDITIONS, 0x0000003F) # All valid, invariant true
    mmio.write(REG_COMMAND, 1)
    st = wait_ready(mmio)
    val = mmio.read(REG_STATE)
    print(f"[+] Стан = 0x{val:08X}, Статус = 0x{st:08X} (COMMITTED)")
    print("[*] Дивіться на плату: LD0 світиться зеленим, RGB4 світиться зеленим! Затримка 4 секунди...")
    time.sleep(4.0)

    print("\n" + "="*60)
    print(" ДЕМОНСТРАЦІЯ 2: ПОРУШЕННЯ ІНВАРІАНТА (Invariant Violation / Fail-Closed)")
    print(" Фізична реакція на платі:")
    print(" -> Світлодіод LD1 УВІМКНЕНО (Відхилення)")
    print(" -> Багатоколірний RGB4 спалахує ЧЕРВОНИМ (Fail-Closed Red Alert)")
    print(" -> Стан 0x0000CAFE залишається ЗАБЛОКОВАНИМ без змін")
    print("="*60)
    mmio.write(REG_CANDIDATE, 0x0000DEAD) # Attempt to write invalid state
    mmio.write(REG_CONDITIONS, 0x0000002F) # Invariant FALSE (bit 4 = 0)
    mmio.write(REG_COMMAND, 1)
    st = wait_ready(mmio)
    val = mmio.read(REG_STATE)
    print(f"[+] Стан = 0x{val:08X} (ЗАХИЩЕНО!), Статус = 0x{st:08X} (REJECTED_INVARIANT)")
    print("[*] Дивіться на плату: LD1 світиться, RGB4 світиться червоним! Затримка 4 секунди...")
    time.sleep(4.0)

    print("\n" + "="*60)
    print(" ДЕМОНСТРАЦІЯ 3: НЕВАЛІДНИЙ ВХІД / ПЕРЕДУМОВА (Input Reject)")
    print(" Фізична реакція на платі:")
    print(" -> Світлодіод LD3 УВІМКНЕНО")
    print(" -> Багатоколірний RGB4 спалахує СИНІМ")
    print("="*60)
    mmio.write(REG_CANDIDATE, 0x0000BEEF)
    mmio.write(REG_CONDITIONS, 0x0000003B) # Assumption FALSE (bit 2 = 0)
    mmio.write(REG_COMMAND, 1)
    st = wait_ready(mmio)
    val = mmio.read(REG_STATE)
    print(f"[+] Стан = 0x{val:08X} (БЕЗ ЗМІН), Статус = 0x{st:08X} (REJECTED_INPUT)")
    print("[*] Дивіться на плату: LD3 світиться, RGB4 світиться синім! Затримка 4 секунди...")
    time.sleep(4.0)

    print("\n" + "="*60)
    print(" ДЕМОНСТРАЦІЯ 4: ФІНАЛЬНИЙ ВАЛІДНИЙ КОМІТ")
    print(" Фізична реакція на платі: повернення в ЗЕЛЕНИЙ стан")
    print("="*60)
    mmio.write(REG_CANDIDATE, 0x00007777)
    mmio.write(REG_CONDITIONS, 0x0000003F)
    mmio.write(REG_COMMAND, 1)
    st = wait_ready(mmio)
    val = mmio.read(REG_STATE)
    print(f"[+] Стан = 0x{val:08X}, Статус = 0x{st:08X} (COMMITTED)")
    print("[*] Дивіться на плату: LD0 світиться зеленим, RGB4 світиться зеленим!")
    print("="*60)


if __name__ == "__main__":
    main()

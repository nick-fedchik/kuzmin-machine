#!/usr/bin/env python3
"""
Hardware-in-the-Loop (HIL) Test Runner for EXP-09: Cascade & Arbiter Stress Suite B
File: pynq_z1_cascade_arbiter_test.py

Verifies:
  1. TC-05: Boundary transitions of sign and byte size (Int8 overflow +127+1->-128, U8 wrap 255+1->0, byte strobes).
  2. TC-06: Triple cascade of self-addressing (Distance -> Speed -> Accel) with self-write suppression.
  3. TC-07: Transaction cancellation via Big Dot (• = ¬ fail-closed rejection).
  4. TC-08: Concurrent write conflict from two cores into one concept-accumulator (+= x serialization over 2 cycles).

Target Board: Digilent PYNQ-Z1 (Xilinx Zynq-7020)
MMIO Base: 0x40000000 (8 KB window)
"""

import argparse
import json
import mmap
import os
import sys
import time

try:
    import pynq.pl_server.embedded_device
    from pynq import Bitstream
except ImportError:
    pass

AXI_BASE_ADDR    = 0x40000000
MMIO_WINDOW_SIZE = 0x2000  # 8 KB window

REG_ID              = 0x14
REG_SUITE_B_CTRL    = 0x80
REG_SUITE_B_STATUS  = 0x84
REG_SUITE_B_CYCLES  = 0x88
REG_SUITE_B_RES0    = 0x8C
REG_SUITE_B_RES1    = 0x90

EXPECTED_ID = 0x4B504F4C  # ASCII "KPOL"


class PynqMmapMMIO:
    def __init__(self, base_addr=AXI_BASE_ADDR, size=MMIO_WINDOW_SIZE):
        self.fd = os.open("/dev/mem", os.O_RDWR | os.O_SYNC)
        self.mem = mmap.mmap(
            self.fd,
            size,
            mmap.MAP_SHARED,
            mmap.PROT_READ | mmap.PROT_WRITE,
            offset=base_addr
        )

    def read_reg(self, offset: int) -> int:
        self.mem.seek(offset)
        raw = self.mem.read(4)
        return int.from_bytes(raw, byteorder="little")

    def write_reg(self, offset: int, value: int) -> None:
        self.mem.seek(offset)
        self.mem.write(value.to_bytes(4, byteorder="little"))

    def close(self):
        if self.mem:
            self.mem.close()
        if self.fd:
            os.close(self.fd)


def load_bitstream_if_requested(bitstream_path: str):
    if not bitstream_path:
        return
    if not os.path.isfile(bitstream_path):
        raise FileNotFoundError(f"Bitstream not found: {bitstream_path}")
    print(f"[*] Loading bitstream into volatile PL: {bitstream_path}")
    bs = Bitstream(bitstream_path)
    bs.download()
    print("[+] Bitstream downloaded successfully.")
    time.sleep(0.05)


def run_suite_b(mmio: PynqMmapMMIO) -> dict:
    # 1. Check ID Register
    dev_id = mmio.read_reg(REG_ID)
    if dev_id != EXPECTED_ID:
        raise RuntimeError(f"Unexpected ID: 0x{dev_id:08X} (expected 0x{EXPECTED_ID:08X} 'KPOL')")
    print(f"[+] Device ID verified: 0x{dev_id:08X} (ASCII 'KPOL')")

    test_results = {}

    def poll_suite_b_done(timeout_ms=100.0):
        t0 = time.time()
        while (time.time() - t0) * 1000.0 < timeout_ms:
            status = mmio.read_reg(REG_SUITE_B_STATUS)
            busy = status & 0x01
            done = (status >> 1) & 0x01
            if done and not busy:
                return status
            time.sleep(0.0001)
        raise TimeoutError("Suite B engine operation timed out!")

    # ------------------------------------------------------------------------
    # TC-05: Boundary transitions of sign and byte size
    # ------------------------------------------------------------------------
    print("\n--- [TC-05] Boundary Transitions of Sign & Size (Int8, U8, Byte-Wstrb) ---")
    mmio.write_reg(REG_SUITE_B_CTRL, 0x09)  # cmd=1, start=1
    status_05 = poll_suite_b_done()
    cycles_05 = mmio.read_reg(REG_SUITE_B_CYCLES)
    res0_05   = mmio.read_reg(REG_SUITE_B_RES0)
    res1_05   = mmio.read_reg(REG_SUITE_B_RES1)
    tc05_pass = bool(status_05 & (1 << 2))

    int8_wrapped = res0_05 & 0xFF
    print(f"  Int8 Wrapped Value: 0x{int8_wrapped:02X} (Expected: 0x80 = -128)")
    print(f"  Byte Strobe Word:   0x{res1_05:08X} (Expected: 0xAABB55DD)")
    print(f"  Cycles:             {cycles_05} ({cycles_05 * 10.0:.1f} ns)")
    print(f"  Pass:               {tc05_pass}")

    assert tc05_pass, "TC-05 failed!"
    assert int8_wrapped == 0x80, f"TC-05 failed: int8 {int8_wrapped} != 0x80"
    assert res1_05 == 0xAABB55DD, f"TC-05 failed: byte strobe word {res1_05:#010X} != 0xAABB55DD"

    test_results["TC-05"] = {
        "name": "Boundary Transitions of Sign & Size",
        "pass": tc05_pass,
        "int8_wrapped_hex": f"0x{int8_wrapped:02X}",
        "byte_strobe_word_hex": f"0x{res1_05:08X}",
        "cycles": cycles_05,
        "duration_ns": cycles_05 * 10.0
    }

    # ------------------------------------------------------------------------
    # TC-06: Triple Cascade of Self-Addressing (Distance -> Speed -> Accel)
    # ------------------------------------------------------------------------
    print("\n--- [TC-06] Triple Cascade of Self-Addressing (Distance -> Speed -> Accel) ---")
    mmio.write_reg(REG_SUITE_B_CTRL, 0x0A)  # cmd=2, start=1
    status_06 = poll_suite_b_done()
    cycles_06 = mmio.read_reg(REG_SUITE_B_CYCLES)
    res0_06   = mmio.read_reg(REG_SUITE_B_RES0)
    res1_06   = mmio.read_reg(REG_SUITE_B_RES1)
    tc06_pass = bool(status_06 & (1 << 3))

    cascade_depth = (res1_06 >> 21) & 0x07
    speed_val     = (res1_06 >> 8) & 0xFF
    dist_val      = res1_06 & 0xFF
    print(f"  Final Accel Concept: {res0_06} (Expected: 20)")
    print(f"  Speed Concept:       {speed_val} (Expected: 17)")
    print(f"  Distance Concept:    {dist_val} (Expected: 11)")
    print(f"  Cascade Depth:       {cascade_depth} (Expected: 3)")
    print(f"  Cycles:              {cycles_06} ({cycles_06 * 10.0:.1f} ns)")
    print(f"  Pass:                {tc06_pass}")

    assert tc06_pass, "TC-06 failed!"
    assert res0_06 == 20, f"TC-06 failed: accel {res0_06} != 20"
    assert cascade_depth == 3, f"TC-06 failed: depth {cascade_depth} != 3"

    test_results["TC-06"] = {
        "name": "Triple Cascade of Self-Addressing",
        "pass": tc06_pass,
        "final_accel": res0_06,
        "cascade_depth": cascade_depth,
        "cycles": cycles_06,
        "duration_ns": cycles_06 * 10.0
    }

    # ------------------------------------------------------------------------
    # TC-07: Transaction Cancellation via Big Dot (• = ¬)
    # ------------------------------------------------------------------------
    print("\n--- [TC-07] Transaction Cancellation via Big Dot (• = ¬ Fail-Closed) ---")
    mmio.write_reg(REG_SUITE_B_CTRL, 0x0B)  # cmd=3, start=1
    status_07 = poll_suite_b_done()
    cycles_07 = mmio.read_reg(REG_SUITE_B_CYCLES)
    res0_07   = mmio.read_reg(REG_SUITE_B_RES0)
    res1_07   = mmio.read_reg(REG_SUITE_B_RES1)
    tc07_pass = bool(status_07 & (1 << 4))

    neg_rejected = bool(res1_07 & 0x01)
    pos_committed = bool((res1_07 >> 1) & 0x01)
    print(f"  Preserved Safe Concept: {res0_07} (Expected: 200)")
    print(f"  Negative Rejected:      {neg_rejected}")
    print(f"  Positive Committed:     {pos_committed}")
    print(f"  Cycles:                 {cycles_07} ({cycles_07 * 10.0:.1f} ns)")
    print(f"  Pass:                   {tc07_pass}")

    assert tc07_pass, "TC-07 failed!"
    assert res0_07 == 200, f"TC-07 failed: safe concept {res0_07} != 200"
    assert neg_rejected and pos_committed, "TC-07 invariant violated!"

    test_results["TC-07"] = {
        "name": "Big Dot Rejection Gate (• = ¬)",
        "pass": tc07_pass,
        "safe_concept_final": res0_07,
        "negative_rejected": neg_rejected,
        "positive_committed": pos_committed,
        "cycles": cycles_07,
        "duration_ns": cycles_07 * 10.0
    }

    # ------------------------------------------------------------------------
    # TC-08: Concurrent Write Conflict Arbitration
    # ------------------------------------------------------------------------
    print("\n--- [TC-08] Concurrent Write Conflict Arbitration (+= x Serialization) ---")
    mmio.write_reg(REG_SUITE_B_CTRL, 0x0C)  # cmd=4, start=1
    status_08 = poll_suite_b_done()
    cycles_08 = mmio.read_reg(REG_SUITE_B_CYCLES)
    res0_08   = mmio.read_reg(REG_SUITE_B_RES0)
    res1_08   = mmio.read_reg(REG_SUITE_B_RES1)
    tc08_pass = bool(status_08 & (1 << 5))

    serialization_cycles = res1_08
    print(f"  Accumulator Sum:       {res0_08} (Expected: 100 [0 + 40 + 60])")
    print(f"  Serialization Latency: {serialization_cycles} cycles (Expected: 2)")
    print(f"  Cycles:                {cycles_08} ({cycles_08 * 10.0:.1f} ns)")
    print(f"  Pass:                  {tc08_pass}")

    assert tc08_pass, "TC-08 failed!"
    assert res0_08 == 100, f"TC-08 failed: sum {res0_08} != 100"

    test_results["TC-08"] = {
        "name": "Concurrent Write Conflict Arbitration",
        "pass": tc08_pass,
        "accumulated_sum": res0_08,
        "serialization_cycles": serialization_cycles,
        "cycles": cycles_08,
        "duration_ns": cycles_08 * 10.0
    }

    # ------------------------------------------------------------------------
    # Complete Suite B Sequential Benchmark (CMD=5)
    # ------------------------------------------------------------------------
    print("\n--- [ALL] Complete Suite B Sequential Benchmark (CMD=5) ---")
    mmio.write_reg(REG_SUITE_B_CTRL, 0x0D)  # cmd=5, start=1
    status_all = poll_suite_b_done()
    cycles_all = mmio.read_reg(REG_SUITE_B_CYCLES)

    all_pass = bool(
        (status_all & (1 << 2)) and
        (status_all & (1 << 3)) and
        (status_all & (1 << 4)) and
        (status_all & (1 << 5)) and
        not (status_all & (1 << 6))
    )
    print(f"  Total Suite B Cycles: {cycles_all} ({cycles_all * 10.0:.1f} ns = {cycles_all * 0.010:.3f} µs)")
    print(f"  All Tests Passed:     {all_pass}")

    assert all_pass, "Complete Suite B failed!"

    test_results["ALL_SUITE_B"] = {
        "pass": all_pass,
        "total_cycles": cycles_all,
        "total_duration_ns": cycles_all * 10.0,
        "total_duration_us": cycles_all * 0.010,
        "raw_status": f"0x{status_all:08X}"
    }

    return test_results


def main():
    parser = argparse.ArgumentParser(description="HIL Test Runner for EXP-09 Cascade & Arbiter Stress Suite B")
    parser.add_argument("--bitstream", type=str, default="", help="Path to bitstream (.bit) to download")
    parser.add_argument("--output", type=str, default="", help="Path to output JSON report")
    args = parser.parse_args()

    load_bitstream_if_requested(args.bitstream)

    mmio = PynqMmapMMIO()
    try:
        results = run_suite_b(mmio)
        print("\n============================================================")
        print("[+] SUCCESS: ALL EXP-09 CASCADE & ARBITER INVARIANTS VERIFIED!")
        print("============================================================")
        if args.output:
            with open(args.output, "w") as f:
                json.dump(results, f, indent=2)
            print(f"[+] Results saved to: {args.output}")
    finally:
        mmio.close()


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""
Hardware-in-the-Loop (HIL) Test & Benchmark Runner for EXP-04 & EXP-05
File: pynq_z1_euclid_hw_test.py

Verifies:
  1. EXP-04: Free-running 64-bit cycle counter (REG_CYCLE_CNT_LO / HI) at 100 MHz.
  2. EXP-04: In-silicon transaction duration profiling (REG_LAST_TXN_CYCLES).
  3. EXP-05: Hardware Euclid Reactive Core (Nod(a, b)) executed purely in PL silicon.
  4. Benchmark comparison: Hardware PL cycles vs ARM Cortex-A9 software execution.

Target Board: Digilent PYNQ-Z1 (Xilinx Zynq-7020, xc7z020clg400-1)
Toolchain: openXC7 (Yosys + nextpnr-himbaechel)
MMIO Base: 0x40000000 (AXI_GP0)
"""

import argparse
import json
import math
import mmap
import os
import sys
import time

AXI_BASE_ADDR = 0x40000000
MMIO_WINDOW_SIZE = 0x1000  # 4 KB page

# Register Map
REG_CANDIDATE        = 0x00
REG_CONDITIONS       = 0x04
REG_COMMAND          = 0x08
REG_STATUS           = 0x0C
REG_STATE            = 0x10
REG_ID               = 0x14
REG_LOWER_BOUND      = 0x18
REG_UPPER_BOUND      = 0x1C
REG_RULE_CFG         = 0x20
REG_PRED_VEC         = 0x24
REG_BIG_DOT          = 0x28
# EXP-04 Registers
REG_CYCLE_CNT_LO     = 0x2C
REG_CYCLE_CNT_HI     = 0x30
REG_LAST_TXN_CYCLES  = 0x34
# EXP-05 Registers
REG_EUCLID_A         = 0x38
REG_EUCLID_B         = 0x3C
REG_EUCLID_CMD       = 0x40
REG_EUCLID_STATUS    = 0x44
REG_EUCLID_CYCLES    = 0x48
REG_EUCLID_RESULT    = 0x4C

EXPECTED_ID = 0x4B504F4C  # ASCII "KPOL"


class PynqMmapMMIO:
    def __init__(self, base_addr=AXI_BASE_ADDR, size=MMIO_WINDOW_SIZE):
        self.fd = os.open("/dev/mem", os.O_RDWR | os.O_SYNC)
        self.mem = mmap.mmap(
            self.fd,
            size,
            mmap.MAP_SHARED,
            mmap.PROT_READ | mmap.PROT_WRITE,
            offset=base_addr
        )

    def read32(self, offset: int) -> int:
        self.mem.seek(offset)
        raw = self.mem.read(4)
        return int.from_bytes(raw, byteorder='little', signed=False)

    def write32(self, offset: int, value: int):
        self.mem.seek(offset)
        self.mem.write(int(value & 0xFFFFFFFF).to_bytes(4, byteorder='little', signed=False))

    def close(self):
        self.mem.close()
        os.close(self.fd)


def program_bitstream(bitstream_path: str):
    print(f"[PYNQ] Loading volatile bitstream into PL SRAM: {bitstream_path}...")
    import pynq.pl_server.embedded_device
    from pynq import Bitstream
    bs = Bitstream(bitstream_path)
    bs.download()
    time.sleep(0.1)
    print("[PYNQ] Bitstream successfully programmed into PL.")


def restore_base_overlay():
    base_path = "/lib/firmware/base.bin"
    if os.path.exists(base_path):
        print(f"[PYNQ] Restoring default base overlay from {base_path}...")
        import pynq.pl_server.embedded_device
        from pynq import Bitstream
        bs = Bitstream(base_path)
        bs.download()
        print("[PYNQ] Baseline overlay restored.")


def py_gcd(a: int, b: int) -> tuple[int, int]:
    """Software Euclid algorithm tracking subtraction iterations."""
    iters = 0
    while a != b:
        if a > b:
            a -= b
        else:
            b -= a
        iters += 1
    return a, iters


def run_benchmark(mmio: PynqMmapMMIO) -> dict:
    results = {
        "device": "Digilent PYNQ-Z1 (xc7z020clg400-1)",
        "toolchain": "openXC7 (Yosys + nextpnr-himbaechel)",
        "clock_freq_mhz": 100.0,
        "exp04_cycle_counter": {},
        "exp04_last_txn_profiler": {},
        "exp05_euclid_runs": [],
        "arm_software_comparison": []
    }

    print("\n" + "="*70)
    print(" 1. HARDWARE ID & REGISTRATION CHECK")
    print("="*70)
    dev_id = mmio.read32(REG_ID)
    id_str = "".join([chr((dev_id >> (8*i)) & 0xFF) for i in range(4)])
    print(f"  [ID] Read ID: 0x{dev_id:08X} (ASCII: '{id_str}')")
    assert dev_id == EXPECTED_ID, f"Unexpected ID: 0x{dev_id:08X}"
    print("  [PASS] Hardware ID matches expected 'KPOL'.")

    print("\n" + "="*70)
    print(" 2. EXP-04: 64-BIT HARDWARE CYCLE COUNTER TEST (100 MHz)")
    print("="*70)
    lo1 = mmio.read32(REG_CYCLE_CNT_LO)
    hi1 = mmio.read32(REG_CYCLE_CNT_HI)
    c1 = (hi1 << 32) | lo1

    time.sleep(0.05)  # 50 ms delay

    lo2 = mmio.read32(REG_CYCLE_CNT_LO)
    hi2 = mmio.read32(REG_CYCLE_CNT_HI)
    c2 = (hi2 << 32) | lo2

    delta_c = c2 - c1
    freq_est = delta_c / 0.05 / 1e6
    print(f"  Sample 1: {c1} cycles")
    print(f"  Sample 2 (after ~50 ms): {c2} cycles")
    print(f"  Delta cycles: {delta_c} cycles (~{delta_c*10.0/1e6:.3f} ms at 100 MHz)")
    print(f"  Estimated clock: {freq_est:.2f} MHz")
    assert delta_c > 0, "Cycle counter is not advancing!"
    print("  [PASS] Free-running 64-bit cycle counter verified.")

    results["exp04_cycle_counter"] = {
        "sample1": c1,
        "sample2": c2,
        "delta_cycles": delta_c,
        "measured_freq_mhz": round(freq_est, 2)
    }

    print("\n" + "="*70)
    print(" 3. EXP-04: IN-SILICON TRANSACTION PROFILER TEST")
    print("="*70)
    # Trigger a single KPOL commit
    mmio.write32(REG_CANDIDATE, 0x12345678)
    mmio.write32(REG_CONDITIONS, 0x3F)  # all known and true
    mmio.write32(REG_RULE_CFG, 0x00)    # direct mode
    mmio.write32(REG_COMMAND, 0x01)     # start transaction

    # Read status and duration
    status = mmio.read32(REG_STATUS)
    last_cycles = mmio.read32(REG_LAST_TXN_CYCLES)
    state = mmio.read32(REG_STATE)

    print(f"  Transaction Status: 0x{status:02X}")
    print(f"  Committed State:    0x{state:08X}")
    print(f"  Captured HW Cycles: {last_cycles} cycles ({last_cycles * 10.0:.1f} ns)")
    results["exp04_last_txn_profiler"] = {
        "status": hex(status),
        "committed_state": hex(state),
        "hardware_cycles": last_cycles,
        "hardware_nanoseconds": last_cycles * 10.0
    }
    print("  [PASS] Hardware transaction duration measured directly in silicon.")

    print("\n" + "="*70)
    print(" 4. EXP-05: PURE PL HARDWARE EUCLID ENGINE BENCHMARK (Nod(a, b))")
    print("="*70)
    test_pairs = [
        (120, 6),       # Key target benchmark (19 iterations, 58 cycles)
        (1071, 462),    # Classic textbook pair -> 21
        (35, 14),       # Small pair -> 7
        (270, 192),     # -> 6
        (252, 105),     # -> 21
        (123456, 12),   # -> 12
    ]

    for a, b in test_pairs:
        # Software golden reference
        sw_res, sw_iters = py_gcd(a, b)

        # Software benchmark timing on ARM Cortex-A9
        t_sw_start = time.perf_counter_ns()
        for _ in range(100):
            py_gcd(a, b)
        t_sw_end = time.perf_counter_ns()
        sw_avg_ns = (t_sw_end - t_sw_start) / 100.0

        # Hardware execution on PL
        mmio.write32(REG_EUCLID_A, a)
        mmio.write32(REG_EUCLID_B, b)
        mmio.write32(REG_EUCLID_CMD, 1)  # pulse start

        # Poll status until done
        timeout = 100000
        while timeout > 0:
            st = mmio.read32(REG_EUCLID_STATUS)
            if (st & 0x02) != 0:  # done bit
                break
            timeout -= 1
        assert timeout > 0, f"Hardware Euclid timed out for ({a}, {b})!"

        hw_res = mmio.read32(REG_EUCLID_RESULT)
        hw_cycles = mmio.read32(REG_EUCLID_CYCLES)
        hw_iters = (st >> 8) & 0xFFFF
        hw_ns = hw_cycles * 10.0  # 10.0 ns per tick @ 100 MHz

        print(f"  Nod({a:6d}, {b:6d}):")
        print(f"    -> HW Result: {hw_res:6d} | Iters: {hw_iters:4d} | HW Cycles: {hw_cycles:5d} ({hw_ns:7.1f} ns)")
        print(f"    -> SW Golden: {sw_res:6d} | Iters: {sw_iters:4d} | ARM Python: ~{sw_avg_ns:7.1f} ns")

        assert hw_res == sw_res, f"HW GCD mismatch: {hw_res} != {sw_res}"
        assert hw_iters == sw_iters, f"HW iteration count mismatch: {hw_iters} != {sw_iters}"

        # Check Nod(120, 6) exact 58 cycles specification invariant
        if a == 120 and b == 6:
            print(f"    [VERIFICATION] Target Nod(120, 6): exact 58 cycles invariant: {hw_cycles} == 58 -> {'PASS' if hw_cycles == 58 else 'FAIL'}")
            assert hw_cycles == 58, f"Expected 58 cycles for Nod(120, 6), got {hw_cycles}"

        speedup = sw_avg_ns / hw_ns if hw_ns > 0 else 1.0
        print(f"    -> HW Execution Speedup vs ARM Python loop: {speedup:.2f}x")

        results["exp05_euclid_runs"].append({
            "a": a,
            "b": b,
            "hw_result": hw_res,
            "hw_iterations": hw_iters,
            "hw_cycles": hw_cycles,
            "hw_latency_ns": hw_ns,
            "sw_iterations": sw_iters,
            "arm_python_avg_ns": round(sw_avg_ns, 1),
            "speedup_vs_arm": round(speedup, 2)
        })

    print("\n" + "="*70)
    print(" ALL PHYSICAL HIL TESTS PASSED (100% OK)")
    print("="*70)
    return results


def main():
    parser = argparse.ArgumentParser(description="EXP-04 & EXP-05 Hardware Euclid HIL Runner")
    parser.add_argument("--bitstream", default="/home/xilinx/kpol_pynq.bit", help="Path to bitstream")
    parser.add_argument("--program", action="store_true", help="Download bitstream into PL SRAM")
    parser.add_argument("--restore-base", action="store_true", help="Restore base.bin after testing")
    parser.add_argument("--output-json", default="euclid_hw_results.json", help="Path for JSON output")
    args = parser.parse_args()

    if args.program:
        program_bitstream(args.bitstream)

    mmio = PynqMmapMMIO()
    try:
        results = run_benchmark(mmio)
        with open(args.output_json, "w", encoding="utf-8") as f:
            json.dump(results, f, indent=2, ensure_ascii=False)
        print(f"\n[INFO] Results saved to: {args.output_json}")
    finally:
        mmio.close()
        if args.restore_base:
            restore_base_overlay()


if __name__ == "__main__":
    main()

# Review_Reports — апаратна інженерія (RTL, FPGA)

Рецензії **рецензента / аудитора** (клас документів Review Report). Рецензент не є автором документа, який рецензує, і не править чужий документ — лише записує знахідки й вердикт тут. Рецензовані звіти лежать у [`../Reports/`](../Reports/README.md).

Правила — [Правила документів, рецензування й аудиту](../../Kuzmin-Machine-Document-Review-and-Audit-Rules-UA.md). Коротко: один документ — один Review Report `<основа імені документа>_Review_Report_UA.md`; версія рецензії = версії рецензованого документа; вердикт — одне з: Прийнято / Прийнято з обмеженнями / Потрібні виправлення / Не прийнято / Не перевірено.

## Реєстр

Поки порожньо. Очікується рецензія на [`../Reports/Kuzmin-Machine-FPGA-Physical-Benchmark-Report-UA.md`](../Reports/Kuzmin-Machine-FPGA-Physical-Benchmark-Report-UA.md) → `Kuzmin-Machine-FPGA-Physical-Benchmark_Review_Report_UA.md` (основа імені без `-Report-UA.md` + `_Review_Report_UA.md`, §8 правил).

#!/usr/bin/env python3
"""
Hardware-in-the-Loop (HIL) Test Runner for EXP-08: RCFC Rendezvous & Fallback Stress Suite
File: pynq_z1_rcfc_stress_test.py

Verifies:
  1. TC-01: Event Avalanche (64x) - 64 simultaneous events without FIFO drop.
  2. TC-02: All-Core Fallback Stress - zero available aux cores, graceful single-core fallback without deadlock.
  3. TC-03: Producer-Before-Consumer - right branch completes before left branch, 0-stall consumption.
  4. TC-04: Consumer-Before-Producer - left branch waits for right branch, unblocks cleanly within T_max <= 256.
  5. SVA-Live Deadlock-Freedom invariant verification in silicon.

Target Board: Digilent PYNQ-Z1 (Xilinx Zynq-7020)
MMIO Base: 0x40000000 (8 KB window)
"""

import argparse
import json
import mmap
import os
import sys
import time

try:
    import pynq.pl_server.embedded_device
    from pynq import Bitstream
except ImportError:
    pass

AXI_BASE_ADDR    = 0x40000000
MMIO_WINDOW_SIZE = 0x2000  # 8 KB window

REG_ID                  = 0x14
REG_CYCLE_CNT_LO        = 0x2C
REG_CYCLE_CNT_HI        = 0x30
REG_LAST_TXN_CYCLES     = 0x34
REG_RCFC_CTRL           = 0x64
REG_RCFC_STATUS         = 0x68
REG_RCFC_CYCLES         = 0x6C
REG_RCFC_SLOT_STATE     = 0x70
REG_RCFC_AVALANCHE_STATS= 0x74
REG_RCFC_RESULT         = 0x78

EXPECTED_ID = 0x4B504F4C  # ASCII "KPOL"


class PynqMmapMMIO:
    def __init__(self, base_addr=AXI_BASE_ADDR, size=MMIO_WINDOW_SIZE):
        self.fd = os.open("/dev/mem", os.O_RDWR | os.O_SYNC)
        self.mem = mmap.mmap(
            self.fd,
            size,
            mmap.MAP_SHARED,
            mmap.PROT_READ | mmap.PROT_WRITE,
            offset=base_addr
        )

    def read_reg(self, offset: int) -> int:
        self.mem.seek(offset)
        raw = self.mem.read(4)
        return int.from_bytes(raw, byteorder="little")

    def write_reg(self, offset: int, value: int) -> None:
        self.mem.seek(offset)
        self.mem.write(value.to_bytes(4, byteorder="little"))

    def close(self):
        if self.mem:
            self.mem.close()
        if self.fd:
            os.close(self.fd)


def load_bitstream_if_requested(bitstream_path: str):
    if not bitstream_path:
        return
    if not os.path.isfile(bitstream_path):
        raise FileNotFoundError(f"Bitstream not found: {bitstream_path}")
    print(f"[*] Loading bitstream into volatile PL: {bitstream_path}")
    bs = Bitstream(bitstream_path)
    bs.download()
    print("[+] Bitstream downloaded successfully.")
    time.sleep(0.05)


def run_rcfc_suite(mmio: PynqMmapMMIO) -> dict:
    # 1. Check ID Register
    dev_id = mmio.read_reg(REG_ID)
    if dev_id != EXPECTED_ID:
        raise RuntimeError(f"Unexpected ID: 0x{dev_id:08X} (expected 0x{EXPECTED_ID:08X} 'KPOL')")
    print(f"[+] Device ID verified: 0x{dev_id:08X} (ASCII 'KPOL')")

    test_results = {}

    # Helper function to poll for done
    def poll_rcfc_done(timeout_ms=100.0):
        t0 = time.time()
        while (time.time() - t0) * 1000.0 < timeout_ms:
            status = mmio.read_reg(REG_RCFC_STATUS)
            busy = status & 0x01
            done = (status >> 1) & 0x01
            if done and not busy:
                return status
            time.sleep(0.0001)
        raise TimeoutError("RCFC engine operation timed out!")

    # ------------------------------------------------------------------------
    # TC-01: Event Avalanche (64x)
    # ------------------------------------------------------------------------
    print("\n--- [TC-01] Event Avalanche (64x) Stress Test ---")
    # Command: cmd=1 (TC-01), start pulse (bit 3=1) -> 0x09
    mmio.write_reg(REG_RCFC_CTRL, 0x09)
    status_01 = poll_rcfc_done()
    cycles_01 = mmio.read_reg(REG_RCFC_CYCLES)
    avalanche_stats = mmio.read_reg(REG_RCFC_AVALANCHE_STATS)
    enqueued = avalanche_stats & 0xFFFF
    dropped  = (avalanche_stats >> 16) & 0xFFFF
    processed = (status_01 >> 16) & 0xFFFF
    tc01_pass = bool(status_01 & (1 << 2))
    drop_err  = bool(status_01 & (1 << 7))

    print(f"  Enqueued:  {enqueued}/64")
    print(f"  Dropped:   {dropped}")
    print(f"  Processed: {processed}/64")
    print(f"  Cycles:    {cycles_01} ({cycles_01 * 10.0:.1f} ns at 100 MHz)")
    print(f"  Pass:      {tc01_pass} (Drop Err: {drop_err})")

    assert tc01_pass, "TC-01 failed: pass bit not set"
    assert dropped == 0, f"TC-01 failed: {dropped} events dropped!"
    assert processed == 64, f"TC-01 failed: only {processed} events processed!"

    test_results["TC-01"] = {
        "name": "Event Avalanche (64x)",
        "pass": tc01_pass,
        "enqueued": enqueued,
        "dropped": dropped,
        "processed": processed,
        "cycles": cycles_01,
        "duration_ns": cycles_01 * 10.0
    }

    # ------------------------------------------------------------------------
    # TC-02: All-Core Fallback Stress
    # ------------------------------------------------------------------------
    print("\n--- [TC-02] All-Core Fallback Stress Test ---")
    # Command: cmd=2 (TC-02), start pulse (bit 3=1) -> 0x0A
    mmio.write_reg(REG_RCFC_CTRL, 0x0A)
    status_02 = poll_rcfc_done()
    cycles_02 = mmio.read_reg(REG_RCFC_CYCLES)
    result_02 = mmio.read_reg(REG_RCFC_RESULT)
    tc02_pass = bool(status_02 & (1 << 3))
    deadlock_err_02 = bool(status_02 & (1 << 6))

    print(f"  Result:        {result_02} (Expected: 150 [50 + 100])")
    print(f"  Cycles:        {cycles_02} ({cycles_02 * 10.0:.1f} ns)")
    print(f"  Deadlock Err:  {deadlock_err_02}")
    print(f"  Pass:          {tc02_pass}")

    assert tc02_pass, "TC-02 failed: pass bit not set"
    assert result_02 == 150, f"TC-02 failed: result {result_02} != 150"
    assert not deadlock_err_02, "TC-02 failed: deadlock error detected!"

    test_results["TC-02"] = {
        "name": "All-Core Fallback Stress",
        "pass": tc02_pass,
        "result": result_02,
        "cycles": cycles_02,
        "duration_ns": cycles_02 * 10.0,
        "deadlock_error": deadlock_err_02
    }

    # ------------------------------------------------------------------------
    # TC-03: Producer-Before-Consumer
    # ------------------------------------------------------------------------
    print("\n--- [TC-03] Producer-Before-Consumer (Right before Left) ---")
    # Command: cmd=3 (TC-03), start pulse (bit 3=1) -> 0x0B
    mmio.write_reg(REG_RCFC_CTRL, 0x0B)
    status_03 = poll_rcfc_done()
    cycles_03 = mmio.read_reg(REG_RCFC_CYCLES)
    result_03 = mmio.read_reg(REG_RCFC_RESULT)
    tc03_pass = bool(status_03 & (1 << 4))

    print(f"  Result:        {result_03} (Expected: 1000 [223 + 777])")
    print(f"  Cycles:        {cycles_03} ({cycles_03 * 10.0:.1f} ns)")
    print(f"  Pass:          {tc03_pass}")

    assert tc03_pass, "TC-03 failed: pass bit not set"
    assert result_03 == 1000, f"TC-03 failed: result {result_03} != 1000"

    test_results["TC-03"] = {
        "name": "Producer-Before-Consumer",
        "pass": tc03_pass,
        "result": result_03,
        "cycles": cycles_03,
        "duration_ns": cycles_03 * 10.0
    }

    # ------------------------------------------------------------------------
    # TC-04: Consumer-Before-Producer
    # ------------------------------------------------------------------------
    print("\n--- [TC-04] Consumer-Before-Producer (Left before Right) ---")
    # Command: cmd=4 (TC-04), start pulse (bit 3=1), delay=30 -> (30 << 8) | 0x0C
    delay_param = 30
    ctrl_val = (delay_param << 8) | 0x0C
    mmio.write_reg(REG_RCFC_CTRL, ctrl_val)
    status_04 = poll_rcfc_done()
    cycles_04 = mmio.read_reg(REG_RCFC_CYCLES)
    result_04 = mmio.read_reg(REG_RCFC_RESULT)
    tc04_pass = bool(status_04 & (1 << 5))
    deadlock_err_04 = bool(status_04 & (1 << 6))

    print(f"  Producer Delay: {delay_param} cycles")
    print(f"  Result:         {result_04} (Expected: 100 [58 + 42])")
    print(f"  Total Cycles:   {cycles_04} ({cycles_04 * 10.0:.1f} ns)")
    print(f"  Deadlock Err:   {deadlock_err_04}")
    print(f"  Pass:           {tc04_pass}")

    assert tc04_pass, "TC-04 failed: pass bit not set"
    assert result_04 == 100, f"TC-04 failed: result {result_04} != 100"
    assert not deadlock_err_04, "TC-04 failed: deadlock timeout triggered!"

    test_results["TC-04"] = {
        "name": "Consumer-Before-Producer",
        "pass": tc04_pass,
        "delay_param_cycles": delay_param,
        "result": result_04,
        "cycles": cycles_04,
        "duration_ns": cycles_04 * 10.0,
        "deadlock_error": deadlock_err_04
    }

    # ------------------------------------------------------------------------
    # Complete Suite Sequential Run (CMD=5)
    # ------------------------------------------------------------------------
    print("\n--- [ALL] Complete Suite Sequential Benchmark (CMD=5) ---")
    # Command: cmd=5, start pulse (bit 3=1) -> 0x0D
    mmio.write_reg(REG_RCFC_CTRL, 0x0D)
    status_all = poll_rcfc_done()
    cycles_all = mmio.read_reg(REG_RCFC_CYCLES)

    all_pass = bool(
        (status_all & (1 << 2)) and
        (status_all & (1 << 3)) and
        (status_all & (1 << 4)) and
        (status_all & (1 << 5)) and
        not (status_all & (1 << 6)) and
        not (status_all & (1 << 7))
    )
    print(f"  Total Suite Cycles: {cycles_all} ({cycles_all * 10.0:.1f} ns = {cycles_all * 0.010:.3f} µs)")
    print(f"  All Tests Passed:   {all_pass}")

    assert all_pass, "Complete Suite failed!"

    test_results["ALL_SUITE"] = {
        "pass": all_pass,
        "total_cycles": cycles_all,
        "total_duration_ns": cycles_all * 10.0,
        "total_duration_us": cycles_all * 0.010,
        "raw_status": f"0x{status_all:08X}"
    }

    return test_results


def main():
    parser = argparse.ArgumentParser(description="HIL Test Runner for EXP-08 RCFC Stress Suite")
    parser.add_argument("--bitstream", type=str, default="", help="Path to bitstream (.bit) to download")
    parser.add_argument("--output", type=str, default="", help="Path to output JSON report")
    args = parser.parse_args()

    load_bitstream_if_requested(args.bitstream)

    mmio = PynqMmapMMIO()
    try:
        results = run_rcfc_suite(mmio)
        print("\n============================================================")
        print("[+] SUCCESS: ALL EXP-08 RCFC STRESS INVARIANTS VERIFIED!")
        print("============================================================")
        if args.output:
            with open(args.output, "w") as f:
                json.dump(results, f, indent=2)
            print(f"[+] Results saved to: {args.output}")
    finally:
        mmio.close()


if __name__ == "__main__":
    main()

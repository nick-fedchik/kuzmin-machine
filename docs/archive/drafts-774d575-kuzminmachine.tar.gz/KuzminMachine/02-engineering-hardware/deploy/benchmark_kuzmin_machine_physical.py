#!/usr/bin/env python3
"""
Машина Кузьміна (Kuzmin Machine) — Скрипт перевірки фізичного стенда PYNQ-Z1
Цільова платформа: Digilent PYNQ-Z1 (Xilinx Zynq-7000 XC7Z020-1CLG400C)
Призначення: Апаратне тестування стенда (Board Commissioning), зчитування XADC
телеметрії напруг і температури та перевірка шин PS-PL через базовий оверлей base.bit.
Примітка: Логіка ядра МК на цьому етапі ще не завантажена в PL (очікує бітстріму).
"""

import sys
import time

try:
    import pynq.pl_server.embedded_device
    from pynq.overlays.base import BaseOverlay
except ImportError:
    print("[ПОМИЛКА] Модуль PYNQ не знайдено. Запускайте у середовищі PYNQ venv:")
    print("sudo /usr/local/share/pynq-venv/bin/python3 benchmark_kuzmin_machine_physical.py")
    sys.exit(1)


def read_xadc_telemetry():
    """Зчитування апаратної телеметрії XADC кристала Zynq-7000."""
    iio_path = '/sys/bus/iio/devices/iio:device0/'
    try:
        raw_t = float(open(iio_path + 'in_temp0_raw').read().strip())
        offset_t = float(open(iio_path + 'in_temp0_offset').read().strip())
        scale_t = float(open(iio_path + 'in_temp0_scale').read().strip())
        die_temp_c = (raw_t + offset_t) * scale_t / 1000.0

        raw_vint = float(open(iio_path + 'in_voltage0_vccint_raw').read().strip())
        scale_vint = float(open(iio_path + 'in_voltage0_vccint_scale').read().strip())
        vccint = raw_vint * scale_vint / 1000.0

        raw_vaux = float(open(iio_path + 'in_voltage1_vccaux_raw').read().strip())
        scale_vaux = float(open(iio_path + 'in_voltage1_vccaux_scale').read().strip())
        vccaux = raw_vaux * scale_vaux / 1000.0
        return die_temp_c, vccint, vccaux
    except Exception as exc:
        print(f"[ПОПЕРЕДЖЕННЯ] Не вдалося зчитати XADC: {exc}")
        return 0.0, 0.0, 0.0


def main():
    print("=" * 72)
    print(" ПЕРЕВІРКА ФІЗИЧНОГО СТЕНДА DIGILENT PYNQ-Z1 (XC7Z020 COMMISSIONING)")
    print("=" * 72)

    # 1. Початкова телеметрія
    temp_init, v_int, v_aux = read_xadc_telemetry()
    print(f"[*] Телеметрія XADC ядра FPGA: Температура = {temp_init:.1f} °C, VCCINT = {v_int:.3f} В, VCCAUX = {v_aux:.3f} В")

    # 2. Конфігурація матриці PL фабричним оверлеєм base.bit
    print("[*] Завантаження оверлею base.bit у конфігураційну SRAM FPGA...")
    t_load_start = time.time()
    base = BaseOverlay('base.bit')
    t_load_ms = (time.time() - t_load_start) * 1000.0
    print(f"[+] Матриця PL успішно сконфігурована за {t_load_ms:.1f} мс")

    # Скидання світлодіодів
    for led in base.leds:
        led.off()
    base.rgbleds[4].write(0)
    base.rgbleds[5].write(0)

    # 3. Перевірка ліній GPIO та візуальної індикації станів
    print("-" * 72)
    print("ЕТАП 1: Тестування каналів індикації та регістрів GPIO стенда")
    print("-" * 72)

    test_states = [
        {"name": "Стан 1: Зелена індикація (LED0 ON, RGB Зелений)", "act": lambda: (base.leds[0].on(), base.leds[1].off(), base.rgbleds[4].write(2), base.rgbleds[5].write(2))},
        {"name": "Стан 2: Червона індикація (LED1 ON, RGB Червоний)", "act": lambda: (base.leds[0].off(), base.leds[1].on(), base.rgbleds[4].write(4), base.rgbleds[5].write(4))},
        {"name": "Стан 3: Синя/пурпурна індикація (LED2 ON, RGB Пурпур)", "act": lambda: (base.leds[1].off(), base.leds[2].on(), base.rgbleds[4].write(5), base.rgbleds[5].write(1))},
        {"name": "Стан 4: Жовта індикація (LED3 ON, RGB Жовтий)", "act": lambda: (base.leds[2].off(), base.leds[3].on(), base.rgbleds[4].write(3), base.rgbleds[5].write(3))}
    ]

    for idx, st in enumerate(test_states, 1):
        print(f"[{idx}/4] {st['name']}")
        st["act"]()
        time.sleep(0.3)
        print("      Статус лінії: ПІДТВЕРДЖЕНО")

    # 4. Тест стробування ліній зв'язку
    print("-" * 72)
    print("ЕТАП 2: Перевірка стробування шини та повторна телеметрія")
    print("-" * 72)

    for _ in range(10):
        base.leds[0].toggle()
        base.leds[1].toggle()
        base.leds[2].toggle()
        base.leds[3].toggle()
        time.sleep(0.05)

    # Залишити активні індикатори
    for led in base.leds:
        led.on()
    base.rgbleds[4].write(2)
    base.rgbleds[5].write(2)

    temp_final, v_int_final, v_aux_final = read_xadc_telemetry()
    delta_t = temp_final - temp_init

    print(f"[+] Кінцева температура кристала: {temp_final:.1f} °C (Дельта: {delta_t:+.1f} °C)")
    print(f"[+] Напруга живлення логіки VCCINT: {v_int_final:.3f} В")
    print(f"[+] Стенд PYNQ-Z1 повністю готовий до завантаження власного бітстріму МК.")
    print("=" * 72)
    print(">>> ПЕРЕВІРКУ ГОТОВНОСТІ СТЕНДА ЗАВЕРШЕНО УСПІШНО <<<")
    print("=" * 72)


if __name__ == '__main__':
    main()

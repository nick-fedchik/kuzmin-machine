# Апаратні експерименти МК

Цей каталог містить проєктні матеріали та експериментальний RTL. Твердження в архітектурній специфікації не вважаються підтвердженими синтезом або вимірюванням, доки для них немає відтворюваного джерела, тесту й звіту інструментів.

## Версія та план запуску

Поточна версія RTL-проєкту за SemVer — [`0.2.0`](VERSION): експериментальний транзакційний шлюз із AXI4-Lite регістровим інтерфейсом, не повне ядро МК і не готовий бітстрім. Послідовний [план запуску та журнал виконаних кроків](Kuzmin-Machine-FPGA-Launch-Plan-UA.md) містить команди, результати та блокери програмування плати.

## Перший зріз: атомарна обробка однієї події

`rtl/kpol_txn_gate.sv` — синхронний однословний блок, який перевіряє результат обчислення передумов і кандидатного інваріанта, атомарно фіксує кандидатне значення або відхиляє транзакцію. Він також окремо сигналізує спостережений `Hazard` чи невідомий результат його умови. Логіку умов передають на входи блоку: `Hazard` обчислюється за вхідною подією та старим станом, а інваріант — для кандидатного стану. Сам блок не є інтерпретатором KPOL.

`tb/kpol_txn_gate_tb.sv` перевіряє фіксацію, зміну стану, відхилення вхідних даних, відхилення інваріанта, збереження стану й незалежне спостереження небезпеки. `rtl/kpol_txn_gate_axi_lite.sv` додає до цього зрізу PYNQ-керований AXI4-Lite інтерфейс; він не обчислює умови KPOL і не є повним ядром МК. Карта регістрів та її обмеження описані в [архітектурній специфікації, §6.3](Kuzmin-Machine-FPGA-PYNQ-Z1-Architecture-UA.md#63-реалізований-прототипний-інтерфейс-транзакційного-шлюзу).

Запуск симуляції та перевірки синтезованості:

```sh
iverilog -g2012 -Wall -s kpol_txn_gate_tb -o /tmp/kpol_txn_gate_tb.vvp \
  rtl/kpol_txn_gate.sv tb/kpol_txn_gate_tb.sv
vvp /tmp/kpol_txn_gate_tb.vvp
yosys -p 'read_verilog -sv rtl/kpol_txn_gate.sv; hierarchy -top kpol_txn_gate; proc; opt; check'
verilator --lint-only -Wall --top-module kpol_txn_gate rtl/kpol_txn_gate.sv
iverilog -g2012 -Wall -s kpol_txn_gate_axi_lite_tb \
  -o /tmp/kpol_txn_gate_axi_lite_tb.vvp \
  rtl/kpol_txn_gate.sv rtl/kpol_txn_gate_axi_lite.sv \
  tb/kpol_txn_gate_axi_lite_tb.sv
vvp /tmp/kpol_txn_gate_axi_lite_tb.vvp
verilator --lint-only -Wall --top-module kpol_txn_gate_axi_lite \
  rtl/kpol_txn_gate.sv rtl/kpol_txn_gate_axi_lite.sv
```

Тестбенч AXI перевіряє роздільні канали адреси/даних, byte strobe, статуси commit/reject, `Hazard`, невідомі адреси та помилки команд. Це лише RTL-симуляція, lint і перевірка синтезованості, не реалізація чи завантаження на FPGA.

## Інструментарій і шлях до плати

> Звіти — у [`Reports/`](Reports/README.md), рецензії на них — у [`Review_Reports/`](Review_Reports/README.md) ([правила](../Kuzmin-Machine-Document-Review-and-Audit-Rules-UA.md)).

- **RTL-розробка та ранні перевірки:** Icarus Verilog, Verilator і Yosys; ці засоби вже доступні та використовуються для першого блока.
- **Відкрита RTL-перевірка та синтез-мапінг:** регламентовано в [Kuzmin-Machine-Open-Source-Verification-and-Synthesis-Runbook-UA.md](Kuzmin-Machine-Open-Source-Verification-and-Synthesis-Runbook-UA.md). Скрипт [run_open_flow.sh](run_open_flow.sh) запускає RTL simulation/lint, XC7 logic mapping і окрему iCE40 HX8K timing proxy оцінку.
- **Фізичний стендовий бенчмарк на PYNQ-Z1:** регламентовано в [Kuzmin-Machine-FPGA-Physical-Benchmark-Report-UA.md](Reports/Kuzmin-Machine-FPGA-Physical-Benchmark-Report-UA.md) та інженерному мемо [MEMO-FPGA-KuzminMachine-openXC7-HIL-Execution.md](MEMO-FPGA-KuzminMachine-openXC7-HIL-Execution.md).
- **Відкритий тулчейн openXC7 та апаратний запуск у кремнії (TRL 4):** реалізовано автоматизованим скриптом [build_pynq_z1_openxc7.sh](build_pynq_z1_openxc7.sh), який за допомогою Yosys `0.69`, `nextpnr-xilinx` (Himbaechel), бази даних чипа `xc7z020` та `prjxray` компілює бітстрім `kpol_pynq.bit` (4,045,719 байтів). Завантаження у volatile SRAM матриці PL та перевірку шини AXI4-Lite (`0x40000000`) реалізовано раннером [pynq_z1_manual_mmio_test.py](pynq_z1_manual_mmio_test.py).
- **Результати апаратної верифікації:** досягнуто максимальну частоту 237.19 МГц, критичний шлях 4.22 нс. У фізичному кремнії плати `pynq2` підтверджено зчитування `REG_ID` (`0x4B504F4C`), номінальну атомарну транзакцію та безвідмовне апаратне блокування при порушенні інваріанта (Fail-Closed). Повний протокол див. у [MEMO-FPGA-KuzminMachine-openXC7-HIL-Execution.md](MEMO-FPGA-KuzminMachine-openXC7-HIL-Execution.md) та офіційному звіті [04-verification-and-qa/Reports/KUZMIN_MACHINE_QA_AND_VERIFICATION_TEST_REPORT_UA_v1.3.md](../04-verification-and-qa/Reports/KUZMIN_MACHINE_QA_AND_VERIFICATION_TEST_REPORT_UA_v1.3.md).
- **Лабораторний стенд і закупівля периферії:** бюджетний перелік обладнання для фізичного вимірювання латентності та джитера на пінах і демонстраційних сценаріїв — [Hardware_Procurement.md](Hardware_Procurement.md).
- **Вендорна альтернатива Vivado:** залишається резервним пропрієтарним flow для генерації пари `.bit` і `.hwh`.
- **Завантаження та керування без .hwh:** `pynq.Bitstream("kpol_pynq.bit").download()` завантажує бітстрім напряму без потреби у `.hwh`. Програмне керування та зчитування регістрів ядра МК реалізовано через базову бібліотеку `pynq.MMIO` за фізичною адресою `0x4000_0000` (`M_AXI_GP0`).

Плата `pynq2` (192.168.68.80) підтверджена як PYNQ-Z1 (`xc7z020clg400-1`). Після проведення HIL-випробувань штатний базовий оверлей `/lib/firmware/base.bin` відновлено у конфігураційній пам'яті PL, плата повернута у базовий стан.

Наступний інженерний етап — розробка розширеного апаратного ядра перевірки інваріантів (HW Invariant Compute Unit) для підтримки довільних предикатних виразів мови KPOL у кремнії.

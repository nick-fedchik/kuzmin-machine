#!/usr/bin/env python3
"""
Машина Кузьміна (Kuzmin Machine) — Науково-інженерний бенчмарк гіпотези H4
Цільова платформа: Digilent PYNQ-Z1 (Xilinx Zynq-7000 XC7Z020, 100 MHz PL FCLK0)
Призначення:
  Порівняння латентності та її варіації для гіпотези H4
  шляхом порівняльного вимірювання затримок:
  1. PL Native Gate Latency (один такт RTL при 100 МГц: 10 нс; фізичний джитер не вимірюється).
  2. PS-PL AXI4-Lite MMIO Round-Trip (Реальний апаратний цикл транзакцій через шину).
  3. Software-Only Dispatch Baseline (Програмна емуляція у просторі користувача Linux).

Пакетна пропускна здатність вимірюється окремо від індивідуальних інтервалів
і включає накладні витрати зовнішнього циклу Python.
"""

import argparse
import json
import math
import os
import sys
import time

try:
    import pynq.pl_server.embedded_device
    from pynq import MMIO
except ImportError:
    print("[ERROR] PYNQ runtime not found. Run inside pynq venv with sudo.")
    sys.exit(1)

REG_CANDIDATE = 0x00
REG_CONDITIONS = 0x04
REG_COMMAND = 0x08
REG_STATUS = 0x0C
REG_STATE = 0x10
REG_ID = 0x14
EXPECTED_ID = 0x4B504F4C

COND_ALL_VALID = 0x0000003F
COND_INVARIANT_FAIL = 0x0000002F


def calculate_stats(samples_ns):
    samples_us = [s / 1000.0 for s in samples_ns]
    samples_us.sort()
    n = len(samples_us)
    mean_us = sum(samples_us) / n
    variance = sum((x - mean_us) ** 2 for x in samples_us) / n
    std_dev_us = math.sqrt(variance)
    median_us = samples_us[n // 2]
    p95_us = samples_us[int(n * 0.95)]
    p99_us = samples_us[int(n * 0.99)]
    min_us = samples_us[0]
    max_us = samples_us[-1]
    return {
        "count": n,
        "min_us": round(min_us, 3),
        "max_us": round(max_us, 3),
        "mean_us": round(mean_us, 3),
        "median_us": round(median_us, 3),
        "p95_us": round(p95_us, 3),
        "p99_us": round(p99_us, 3),
        "std_dev_jitter_us": round(std_dev_us, 3),
    }


def run_benchmark(iterations=10000, base_addr=0x40000000, size=0x1000):
    print("=" * 76)
    print(" НАУКОВО-ІНЖЕНЕРНИЙ БЕНЧМАРК ГІПОТЕЗИ H4: ЛАТЕНТНІСТЬ ТА ДЖИТЕР МК")
    print(f" Платформа: Xilinx Zynq-7000 (XC7Z020) @ 100 MHz PL Clock (T_clk = 10.0 ns)")
    print(f" Кількість ітерацій вибірки: N = {iterations}")
    print("=" * 76)

    mmio = MMIO(base_addr, size)
    chip_id = mmio.read(REG_ID)
    if chip_id != EXPECTED_ID:
        raise RuntimeError(
            f"Невірний ID ядра: 0x{chip_id:08X} (очікувалося 0x{EXPECTED_ID:08X} 'KPOL')"
        )
    print(f"[+] Зв'язок із PL підтверджено: REG_ID = 0x{chip_id:08X} (ASCII 'KPOL')")

    # 1. Warm-up
    for i in range(100):
        mmio.write(REG_CANDIDATE, i)
        mmio.write(REG_CONDITIONS, COND_ALL_VALID)
        mmio.write(REG_COMMAND, 0x01)
        _ = mmio.read(REG_STATUS)
        _ = mmio.read(REG_STATE)

    # 2. Hardware AXI4-Lite MMIO Transaction Benchmark
    print(f"[*] Вимірювання PS-PL AXI4-Lite Round-Trip Latency ({iterations} транзакцій)...")
    hw_latencies_ns = []
    t_hw_start = time.perf_counter()

    for i in range(iterations):
        cand = (0x1000 + i) & 0xFFFFFFFF
        cond = COND_ALL_VALID if (i % 2 == 0) else COND_INVARIANT_FAIL

        t0 = time.perf_counter_ns()
        mmio.write(REG_CANDIDATE, cand)
        mmio.write(REG_CONDITIONS, cond)
        mmio.write(REG_COMMAND, 0x01)
        st = mmio.read(REG_STATUS)
        val = mmio.read(REG_STATE)
        t1 = time.perf_counter_ns()

        hw_latencies_ns.append(t1 - t0)

    t_hw_total = time.perf_counter() - t_hw_start
    hw_stats = calculate_stats(hw_latencies_ns)
    hw_throughput = round(iterations / t_hw_total, 1)

    # 3. Software-Only Baseline Benchmark (Pure Python Userspace on Cortex-A9)
    print(f"[*] Вимірювання Software-Only Userspace Baseline ({iterations} транзакцій)...")
    sw_latencies_ns = []
    sw_state = 0x00000000
    t_sw_start = time.perf_counter()

    for i in range(iterations):
        cand = (0x1000 + i) & 0xFFFFFFFF
        cond = COND_ALL_VALID if (i % 2 == 0) else COND_INVARIANT_FAIL

        t0 = time.perf_counter_ns()
        # Софтверна емуляція логіки перевірки умов kpol
        inv_known = (cond & (1 << 3)) != 0
        inv_true = (cond & (1 << 4)) != 0
        assump_known = (cond & (1 << 1)) != 0
        assump_true = (cond & (1 << 2)) != 0

        if inv_known and inv_true and assump_known and assump_true:
            sw_status = 0x00000003  # DONE | COMMITTED
            sw_state = cand
        else:
            sw_status = 0x00000015  # DONE | REJECTED | REJECTED_INVARIANT
            # sw_state залишається без змін
        t1 = time.perf_counter_ns()

        sw_latencies_ns.append(t1 - t0)

    t_sw_total = time.perf_counter() - t_sw_start
    sw_stats = calculate_stats(sw_latencies_ns)
    sw_throughput = round(iterations / t_sw_total, 1)

    # 4. Циклові параметри PL Core (RTL/clock; фізичний джитер не вимірювався)
    pl_core_stats = {
        "clock_frequency_mhz": 100.0,
        "clock_period_ns": 10.0,
        "f_max_sta_mhz": 221.53,
        "critical_path_delay_ns": 4.514,
        "gate_evaluation_cycles": 1,
        "gate_latency_ns": 10.0,
        "physical_jitter_ns": None,
        "physical_jitter_measured": False,
        "cycle_count_deterministic": True,
    }

    # 5. Результати та висновки
    results = {
        "timestamp_utc": time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime()),
        "target_part": "xc7z020clg400-1",
        "board": "Digilent PYNQ-Z1 (pynq2)",
        "pl_core": pl_core_stats,
        "ps_pl_axi_mmio": {
            "throughput_tx_per_sec": hw_throughput,
            "total_time_sec": round(t_hw_total, 3),
            "stats": hw_stats,
        },
        "sw_userspace": {
            "throughput_tx_per_sec": sw_throughput,
            "total_time_sec": round(t_sw_total, 3),
            "stats": sw_stats,
        },
    }

    print("\n" + "=" * 76)
    print(" РЕЗУЛЬТАТИ ВИМІРЮВАНЬ:")
    print("=" * 76)
    print(f" 1. PL Native Core (Вентильний рівень FPGA):")
    print(f"    - Циклова латентність RTL:    10.000 нс (1 такт на 100 МГц)")
    print(f"    - Фізичний джитер виходу:     не вимірювався")
    print(f"    - Статичний таймінг openXC7:  f_max 221.53 МГц (шлях 4.514 нс)")
    print("-" * 76)
    print(f" 2. PS-PL AXI4-Lite MMIO Round-Trip (Шинний рівень):")
    print(f"    - Середня затримка (mean):    {hw_stats['mean_us']} мкс")
    print(f"    - Медіана (median):           {hw_stats['median_us']} мкс")
    print(f"    - 95-й перцентиль (p95):      {hw_stats['p95_us']} мкс")
    print(f"    - 99-й перцентиль (p99):      {hw_stats['p99_us']} мкс")
    print(f"    - Мінімум / максимум:         {hw_stats['min_us']} / {hw_stats['max_us']} мкс")
    print(f"    - Розкид латентності (std_dev): {hw_stats['std_dev_jitter_us']} мкс")
    print(f"    - Пакетна швидкість:          {hw_throughput} транзакцій/сек")
    print("-" * 76)
    print(f" 3. Software Userspace Emulation (ARM Cortex-A9 Linux):")
    print(f"    - Середня затримка (mean):    {sw_stats['mean_us']} мкс")
    print(f"    - Медіана (median):           {sw_stats['median_us']} мкс")
    print(f"    - 95-й перцентиль (p95):      {sw_stats['p95_us']} мкс")
    print(f"    - 99-й перцентиль (p99):      {sw_stats['p99_us']} мкс")
    print(f"    - Мінімум / максимум:         {sw_stats['min_us']} / {sw_stats['max_us']} мкс")
    print(f"    - Розкид латентності (std_dev): {sw_stats['std_dev_jitter_us']} мкс")
    print(f"    - Пакетна швидкість:          {sw_throughput} ітерацій/сек")
    print("=" * 76)

    print("\n[ІНТЕРПРЕТАЦІЯ РЕЗУЛЬТАТІВ H4]:")
    print(" 1. PL: RTL задає оцінку за один такт (10 нс при 100 МГц);")
    print("    фізичний джитер виходу цим скриптом не вимірюється.")
    print(
        f" 2. AXI4-Lite: mean {hw_stats['mean_us']} мкс, "
        f"sigma {hw_stats['std_dev_jitter_us']} мкс, "
        f"p99 {hw_stats['p99_us']} мкс, max {hw_stats['max_us']} мкс."
    )
    print(
        f" 3. Linux userspace: mean {sw_stats['mean_us']} мкс, "
        f"sigma {sw_stats['std_dev_jitter_us']} мкс, "
        f"p99 {sw_stats['p99_us']} мкс, max {sw_stats['max_us']} мкс."
    )
    print("    Варіація виміряна для цього запуску; її причини окремо не ізольовано.")
    print(" 4. Пакетна швидкість рахується за зовнішнім таймером і включає")
    print("    підготовку ітерацій та облік результатів; вона не дорівнює 1/mean.")
    print("=" * 76)

    output_path = "/home/xilinx/h4_benchmark_results.json"
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    print(f"[+] Сирі результати збережено: {output_path}")

    return results


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="H4 Latency and Jitter Benchmark")
    parser.add_argument(
        "-n",
        "--iterations",
        type=int,
        default=10000,
        help="Кількість транзакцій (за замовчуванням: 10000)",
    )
    args = parser.parse_args()
    run_benchmark(iterations=args.iterations)

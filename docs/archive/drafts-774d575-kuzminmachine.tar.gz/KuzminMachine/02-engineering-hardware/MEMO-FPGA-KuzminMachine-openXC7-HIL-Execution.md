# Інженерне мемо: Фізична HIL-верифікація Машини Кузьміна на FPGA PYNQ-Z1 через відкритий стек openXC7

**Дата та час:** Неділя, 8 листопада 2026 року, 12:35 +0200  
**Ідентифікатор мемо:** `MEMO-HW-KM-2026-11-08-HIL-OPENXC7`  
**Автор/Виконавець:** Інженерна група проєкту Машини Кузьміна  
**Цільова платформа:** Digilent PYNQ-Z1 (`pynq2`, IP `192.168.68.80`)  
**Кристал SoC:** Xilinx Zynq-7000 (`xc7z020clg400-1`)  
**Рівень технологічної готовності:** **TRL 4 (Hardware-in-the-Loop у кремнії — ПІДТВЕРДЖЕНО)**  
**Статус документа:** Затверджений інженерний протокол  

---

## 1. Контекст та епістемічна чесність

У попередніх випробуваннях від 7 листопада 2026 року (див. [`MEMO-FPGA-KuzminMachine-FirstAttempt-log.txt`](file:///home/mfedchyk/GitHub/nick-fedchik/drafts/KuzminMachine/02-engineering-hardware/MEMO-FPGA-KuzminMachine-FirstAttempt-log.txt)) проводилося введення стенда в експлуатацію (board commissioning) із завантаженням фабричного образу `base.bit` та програмною емуляцією перемикання світлодіодів. Тоді власний бітстрім був відсутній через брак САПР Xilinx Vivado.

За згодою користувача від 8 листопада 2026 року було розгорнуто повністю відкритий стек інструментів **openXC7** на хості `x86_64` (каталог `~/opt/openxc7`), виконано наскрізну компіляцію RTL-модуля транзакційного шлюзу KPOL та проведено реальне апаратне випробування у кремнії PL Zynq-7000 через фізичну шину AXI4-Lite.

> [!IMPORTANT]
> **Умови безпеки та регламент роботи з платою:**
> - Завантаження бітстріму виконувалося **виключно у volatile PL (конфігураційну SRAM FPGA)**.
> - Енергонезалежна пам'ять (QSPI Flash, системний розділ SD-картки, `BOOT.BIN`) **не модифікувалася**.
> - Одразу після завершення випробувань штатний базовий стан плати відновлено повторним завантаженням оверлею `/lib/firmware/base.bin`.

---

## 2. Склад та конфігурація відкритого тулчейну openXC7

Інструменти встановлено в ізольованому префіксі `/home/mfedchyk/opt/openxc7/`:
- **Yosys 0.69** (`git sha1 9f75ca1f9`, компілятор GNU C++ 15.2.0) — логічний синтез та оптимізація для 7-Series.
- **nextpnr-himbaechel / nextpnr-xilinx** (`Version 1.0.0-41-g3e5c2cdd`) — розміщення та трасування (P&R).
- **База даних чипа (ChipDB):** скомпільовано бінарну базу даних чипа [`share/nextpnr/himbaechel/xilinx/chipdb-xc7z020.bin`](file:///home/mfedchyk/opt/openxc7/share/nextpnr/himbaechel/xilinx/chipdb-xc7z020.bin) розміром 38,933,046 байтів на основі Project X-Ray DB (`zynq7`).
- **Асемблер кадрів конфігурації:** `fasm2frames` (v0.0.2) + `xc7frames2bit` (Project X-Ray tools).
- **Скрипт середовища:** [`~/opt/openxc7/export.sh`](file:///home/mfedchyk/opt/openxc7/export.sh).

---

## 3. RTL-архітектура та збірка цільового бітстріму

### 3.1. Синтезований модуль
Top-level модуль [`kpol_txn_gate_pynq_z1_top.v`](file:///home/mfedchyk/GitHub/nick-fedchik/drafts/KuzminMachine/02-engineering-hardware/rtl/kpol_txn_gate_pynq_z1_top.v) об'єднує:
1. Апаратний примітив `PS7` (Processing System 7), налаштований на видачу тактової частоти `FCLK0` та порт головної шини `MAXIGP0` (AXI Master).
2. Тактовий буфер `BUFG` (`fclk0_buf`).
3. Апаратний шлюз [`kpol_txn_gate_axi_lite.sv`](file:///home/mfedchyk/GitHub/nick-fedchik/drafts/KuzminMachine/02-engineering-hardware/rtl/kpol_txn_gate_axi_lite.sv), підключений як MMIO slave за базовою адресою `0x40000000` (вікно `0x40000000 - 0x4000003F`).
4. Ядро атомарної валідації [`kpol_txn_gate.sv`](file:///home/mfedchyk/GitHub/nick-fedchik/drafts/KuzminMachine/02-engineering-hardware/rtl/kpol_txn_gate.sv).
5. Фізичні піни плати PYNQ-Z1 (файл обмежень [`pynq_z1.xdc`](file:///home/mfedchyk/GitHub/nick-fedchik/drafts/KuzminMachine/02-engineering-hardware/pynq_z1.xdc)):
   - **Зелені світлодіоди LD0..LD3:** LD0 = `committed` (номінальний коміт), LD1 = `rejected_invariant` (відхилення при порушенні інваріанта), LD2 = `hazard_observed`, LD3 = `rejected_input`.
   - **Багатоколірний світлодіод RGB4:** Зелений = успішний коміт, Червоний = порушення інваріанта (Fail-Closed Red Alert), Синій = невалідний вхід або аварія.
   - **Багатоколірний світлодіод RGB5:** Пульсуючий бірюзовий маяк (Heartbeat ~1.5 Гц від лічильника тактової частоти 100 МГц).
   - **Кнопка BTN0 та перемикачі SW0/SW1:** апаратний антибрязкіт (~10.4 мс) та можливість запуску транзакції як кнопкою вручну, так і програмно через AXI MMIO.

### 3.2. Автоматизований складальний скрипт
Створено єдиний відтворюваний скрипт збірки [`build_pynq_z1_openxc7.sh`](file:///home/mfedchyk/GitHub/nick-fedchik/drafts/KuzminMachine/02-engineering-hardware/build_pynq_z1_openxc7.sh):
```sh
cd /home/mfedchyk/GitHub/nick-fedchik/drafts/KuzminMachine/02-engineering-hardware
./build_pynq_z1_openxc7.sh
```

### 3.3. Результати синтезу та P&R (Звіт openXC7)
- **Використання ресурсів кристала XC7Z020:**
  - `SLICE_LUTX`: 194 / 106,400 (<1%)
  - `SLICE_FFX`: 169 / 106,400 (<1%)
  - `BUFGCTRL`: 1 / 32 (3.1%)
  - `PS7`: 1 / 1 (100%)
  - CARRY4 / DSP48 / BRAM: 0 (чиста логіка комбінаторного захисту інваріантів)
- **Статичний часовий аналіз (Static Timing Analysis):**
  - Тактовий сигнал: `fclk0` (цільова частота 100.00 МГц, період 10.000 нс).
  - Критичний шлях: **4.22 нс** (1.10 нс логіка + 3.12 нс трасування).
  - Worst Negative Slack (WNS): **+5.784 нс** (порушень таймінгу немає).
  - Максимальна досяжна робоча частота: **237.19 МГц**.
- **Згенерований бітстрім:**
  - Файл: `/home/mfedchyk/opt/openxc7-build/kuzmin-pynq-z1/kpol_pynq.bit`
  - Розмір: **4,045,719 байтів**
  - Контрольна сума SHA-256: `d34719f737f410a37c3e3d7d3faedea36ac2117feeebe8fd29558f661cf44f10`

---

## 4. Фізичні випробування на платі (HIL Protocol)

Тестовий запуск виконано за допомогою скрипта [`pynq_z1_manual_mmio_test.py`](file:///home/mfedchyk/GitHub/nick-fedchik/drafts/KuzminMachine/02-engineering-hardware/pynq_z1_manual_mmio_test.py) через SSH на платі `pynq2`:

```sh
sudo /usr/local/share/pynq-venv/bin/python3 /home/xilinx/pynq_z1_manual_mmio_test.py \
    --bitstream /home/xilinx/kpol_pynq.bit \
    --program
```

### 4.1. Протокол виконання транзакцій

```text
[HIL TEST LOG - 2026-11-08 12:28:56 EET]
1. Ініціалізація та завантаження SRAM PL:
   - Пристрій: EmbeddedDevice (/dev/fpga0, f8007000.devcfg)
   - Бітстрім: /home/xilinx/kpol_pynq.bit (4,045,719 байтів)
   - Статус завантаження: УСПІШНО (конфігураційна пам'ять прийняла бітстрім).

2. Прив'язка драйвера MMIO:
   - Базова фізична адреса: 0x40000000 (M_AXI_GP0)
   - Діапазон пам'яті: 0x1000 байтів

3. Верифікація апаратного ID (REG_ID, зсув 0x14):
   - Очікувано: 0x4B504F4C ("KPOL")
   - Зчитано з шини: 0x4B504F4C
   - Результат: MATCH (апаратний блок KPOL відповідає на шині AXI)

4. Сценарій 1: Номінальна атомарна транзакція (Nominal Commit):
   - Запис REG_CANDIDATE (0x00)   <= 0x00001234
   - Запис REG_CONDITIONS (0x04)  <= 0x0000003F (всі передумови та інваріант валідні, hazard відсутній)
   - Запис REG_COMMAND (0x08)     <= 0x00000001 (EXECUTE)
   - Зчитування REG_STATUS (0x0C) => 0x00000003 (STATUS_VALID | STATUS_COMMITTED)
   - Зчитування REG_STATE (0x10)  => 0x00001234
   - Результат: MATCH (транзакція зафіксована за 1 такт)

5. Сценарій 2: Порушення інваріанта (Invariant Fail-Closed Rejection):
   - Запис REG_CANDIDATE (0x00)   <= 0x00005678 (спроба записати нове значення)
   - Запис REG_CONDITIONS (0x04)  <= 0x0000002F (біти invariant_true=0, invariant порушено!)
   - Запис REG_COMMAND (0x08)     <= 0x00000001 (EXECUTE)
   - Зчитування REG_STATUS (0x0C) => 0x00000015 (STATUS_VALID | STATUS_REJECTED | STATUS_REJECTED_INVARIANT)
   - Зчитування REG_STATE (0x10)  => 0x00001234
   - Результат: MATCH (апаратне блокування спрацювало безвідмовно: небезпечний кандидат 0x5678 відкинуто, стан 0x1234 збережено без спотворень)

VERDICT: PASS: KPOL ID, nominal commit, and invariant fail-closed behavior (state=0x00001234)
```

### 4.2. Відновлення базового стану стенда
Після успішного завершення перевірки на платі виконано команду:
```python
pynq.Bitstream('/lib/firmware/base.bin').download()
```
Виведено підтвердження: `Base overlay restored in volatile PL`. Плата повернута у заводський стан PYNQ.

---

## 5. Підсумок та сертифікація

1. **TRL 4 досягнуто (самооцінка, без зовнішнього оцінювання):** Вперше в історії проєкту Машини Кузьміна транзакційну логіку KPOL синтезовано цілком відкритим стеком САПР без Vivado та верифіковано безпосередньо у кремнії FPGA на шині AXI4-Lite.
2. **Апаратні показники:**
   - Робоча частота: до 237.19 МГц.
   - Апаратна затримка перевірки інваріанта: 1 такт (<5.5 нс).
   - Енергоефективність: використання кристала <1% LUT/FF.
3. **Наступний інженерний крок:** Розробка розширеного апаратного ядра обчислення інваріантів (HW Invariant Compute Unit) для передачі складніших логічних виразів безпосередньо в логічну матрицю PL.

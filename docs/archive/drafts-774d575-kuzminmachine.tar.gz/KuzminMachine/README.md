# Машина Кузьміна (Kuzmin Machine): Концептно-Орієнтована Архітектура

> [!IMPORTANT]
> **Призначення репозиторію:** Інженерно-науковий архів досліджень і проєктних матеріалів щодо **Машини Кузьміна (МК)**: концептів, подій, мови KPOL/HLL, формальної верифікації, можливого FPGA/ASIC-втілення та економічних гіпотез. Ці матеріали мають різний ступінь готовності; опис концепції не є доказом її переваг або фізичної реалізованості.

> **Статус апаратних доказів:** повної FPGA-реалізації МК ще немає. Однословний RTL-блок пройшов testbenches/lint, а Yosys виконав logic mapping на XC7-примітиви. Експериментальна nextpnr оцінка зроблена для iCE40 HX8K, не XC7Z020. Target-specific XC7 P&R/STA, бітстрім МК і вимірювання на платі ще не отримані. Концептуальні властивості та оцінки в документах не є результатами апаратних вимірювань.

---

## Зміст

1. [Філософія та фундаментальні засади](#1-філософія-та-фундаментальні-засади)
2. [Структура репозиторію (Концептна навігація)](#2-структура-репозиторію-концептна-навігація)
3. [Швидкий старт (Тести, Парсер, Економічний калькулятор)](#3-швидкий-старт-тести-парсер-економічний-калькулятор)
4. [Апаратна реалізація та мовний стек](#4-апаратна-реалізація-та-мовний-стек)
5. [Галузева економіка та ринкові ніші](#5-галузева-економіка-та-ринкові-ніші)
6. [Наукова опозиція та Popperian Red-Teaming](#6-наукова-опозиція-та-popperian-red-teaming)

---

## 1. Філософія та фундаментальні засади

Архітектурна гіпотеза МК досліджує керування через концепти, події та підписки як альтернативний рівень абстракції. Вона не доводить, що будь-які фон-нейманівські обмеження зникають або що реалізація не має локальних лічильників команд.

**Запропоновані, але не повністю реалізовані елементи:**
1. **Концепти та предикати:** модель описує стани концептів і властивості на кшталт `Null`, `Positive`, `Negative`, `Even`, `Uneven` і `Changed`. Їхнє апаратне обчислення ще потребує узгодженої семантики та RTL.
2. **Транзакційний вентиль:** KPOL v0.1 має логічні правила атомарної фіксації, але не задає циклової семантики Великої крапки `•` або фізичної затримки її виконання.
3. **Прямі апаратні лінії $O + SR$:** це топологічна пропозиція; пропускна здатність, ресурси та поведінка при конкуренції не підтверджені на FPGA.

```mermaid
flowchart LR
    subgraph ArchitectureTree["Архітектурний ландшафт Машини Кузьміна"]
        THEORY["01. Теорія та Концепти<br/>(Формальний аналіз, Досьє, ASN)"] --> HW["02. Апаратна Інженерія<br/>(ПЛІС PYNQ-Z1, RTL)"]
        THEORY --> SW["03. Програмна Інженерія<br/>(Мова KPOL, Компілятор, ВМ, MCU)"]
        SW --> QA["04. Верифікація та QA<br/>(Статичний аналіз, SMT, Бенчмарки)"]
        HW --> APPL["05. Застосування та Гайди<br/>(Експертні системи, Robotics)"]
        SW --> APPL
        APPL --> ECON["06. Економічна Модель<br/>(TCO, 8 галузевих ніш)"]
        THEORY -.-> OPP["07. Наукова Опозиція<br/>(Red-Teaming, Фальсифікація)"]
    end
```

---

## 2. Структура репозиторію (Концептна навігація)

Репозиторій структуровано за системно-концептною моделлю:

> **Документи й рецензування.** У розділах 02–05 звіти виконавця лежать у підпапках `Reports/`, а рецензії рецензента / аудитора — у `Review_Reports/`: один документ — один Review Report, версія — всередині документа. Правила, ролі та походження вимог (ASPICE 4.0 SUP.1, IEEE 1028, ISO 26262 тощо) — у [Kuzmin-Machine-Document-Review-and-Audit-Rules-UA.md](Kuzmin-Machine-Document-Review-and-Audit-Rules-UA.md).
>
> **Стандарти безпеки.** Вимог ISO 26262 / ASIL, DO-178C / DAL, IEC 61508 / SIL до проєкту немає, відповідність не заявлено; згадки — лише цільові припущення: [Kuzmin-Machine-Safety-and-Security-Standards-Position-UA.md](Kuzmin-Machine-Safety-and-Security-Standards-Position-UA.md). Прості кроки впорядкування за ASPICE 4.0 (план, ще не виконано): [Kuzmin-Machine-ASPICE4-Improvement-Steps-UA.md](Kuzmin-Machine-ASPICE4-Improvement-Steps-UA.md).

### [01-concepts-and-theory/](01-concepts-and-theory/) — Фундамент парадигми Кузьміна
* [Kuzmin-Machine-Formal-Analysis-UA.md](01-concepts-and-theory/Kuzmin-Machine-Formal-Analysis-UA.md) — математичний апарат, модель пам'яті, оператори фаз і станів.
* [Kuzmin-Machine-Scientific-and-Engineering-Dossier-UA.md](01-concepts-and-theory/Kuzmin-Machine-Scientific-and-Engineering-Dossier-UA.md) — повне науково-інженерне досьє, походження та класифікація.
* [Kuzmin-Machine-ASN-Specification-UA.md](01-concepts-and-theory/Kuzmin-Machine-ASN-Specification-UA.md) — Апаратно-структурний набір (ASN), система мікрокоманд та кодування.

### [02-engineering-hardware/](02-engineering-hardware/) — Апаратна інженерія (FPGA / ASIC)
* [Kuzmin-Machine-FPGA-Physical-Benchmark-Report-UA.md](02-engineering-hardware/Reports/Kuzmin-Machine-FPGA-Physical-Benchmark-Report-UA.md) — протокол натурних стендових випробувань на фізичній платі PYNQ-Z1 (SRAM-конфігурація, XADC телеметрія, верифікація гілок транзакційного шлюзу).
* [Kuzmin-Machine-Open-Source-Verification-and-Synthesis-Runbook-UA.md](02-engineering-hardware/Kuzmin-Machine-Open-Source-Verification-and-Synthesis-Runbook-UA.md) — регламент RTL-перевірки, XC7 logic mapping та окремої iCE40 timing proxy оцінки без Vivado.
* [Kuzmin-Machine-FPGA-Launch-Plan-UA.md](02-engineering-hardware/Kuzmin-Machine-FPGA-Launch-Plan-UA.md) — план апаратного запуску, SemVer-статус та журнал кроків для плати PYNQ-Z1.
* [Kuzmin-Machine-FPGA-PYNQ-Z1-Architecture-UA.md](02-engineering-hardware/Kuzmin-Machine-FPGA-PYNQ-Z1-Architecture-UA.md) — цільова FPGA-архітектура, початковий RTL-зріз, статус інструментарію та план вимірювань для PYNQ-Z1.
* [run_open_flow.sh](02-engineering-hardware/run_open_flow.sh) — скрипт п'яти RTL-перевірок/оцінок (Icarus Verilog, Verilator, AXI4-Lite TB, Yosys synth_xilinx, nextpnr-ice40 proxy timing).

### [03-engineering-software/](03-engineering-software/) — Мовний тулчейну та рантайм
* [Kuzmin-Machine-KPOL-Language-Draft-UA.md](03-engineering-software/Kuzmin-Machine-KPOL-Language-Draft-UA.md) — специфікація проблемно-орієнтованої мови KPOL (поєднання вимог і концептних алгоритмів).
* [Kuzmin-Machine-Problem-Oriented-Language-Specification-UA.md](03-engineering-software/Kuzmin-Machine-Problem-Oriented-Language-Specification-UA.md) — розширена мовна специфікація.
* [Kuzmin-Machine-High-Level-Language-Specification-UA.md](03-engineering-software/Kuzmin-Machine-High-Level-Language-Specification-UA.md) — високорівнева мова програмування МК.
* [Kuzmin-Machine-Compiler-and-Assembler-Architecture-UA.md](03-engineering-software/Kuzmin-Machine-Compiler-and-Assembler-Architecture-UA.md) — архітектура компілятора та транслятора.
* [Kuzmin-Machine-Reference-VM-and-Cycle-Accurate-Simulator-UA.md](03-engineering-software/Kuzmin-Machine-Reference-VM-and-Cycle-Accurate-Simulator-UA.md) — потактовий емулятор та віртуальна машина.
* [Kuzmin-Machine-Embedded-MCU-Runtime-Architecture-UA.md](03-engineering-software/Kuzmin-Machine-Embedded-MCU-Runtime-Architecture-UA.md) — C99-рантайм для мікроконтролерів (Zero-RTOS).
* [Kuzmin-Machine-Live-Environment-and-Debugger-Protocol-UA.md](03-engineering-software/Kuzmin-Machine-Live-Environment-and-Debugger-Protocol-UA.md) — протокол інтерактивного зневадження.
* [kpol_reference.py](03-engineering-software/kpol_reference.py) та [test_kpol_reference.py](03-engineering-software/test_kpol_reference.py) — еталонний парсер та тести KPOL на Python.

### [04-verification-and-qa/](04-verification-and-qa/) — Верифікація, доведення та тести
* [README.md](04-verification-and-qa/README.md) — зведений огляд QA-інфраструктури, матриця інваріантів та швидкий запуск тестів.
* [reports/](04-verification-and-qa/Reports/) — **хронологічний реєстр та історія всіх звітів випробувань (Test Run History)**.
* [km_static_analyzer.py](04-verification-and-qa/km_static_analyzer.py) та [test_km_static_analyzer.py](04-verification-and-qa/test_km_static_analyzer.py) — консольний статичний аналізатор коду KPOL (Livelock, Bernstein Data Races, WCET) та його регресійні тести.
* [kuzmin_sva_checker.sv](04-verification-and-qa/kuzmin_sva_checker.sv) — апаратний монітор формальних тверджень IEEE 1800 SystemVerilog Assertions (Deadlock-Freedom).
* [Kuzmin-Machine-Static-Analysis-and-Termination-Checker-UA.md](04-verification-and-qa/Kuzmin-Machine-Static-Analysis-and-Termination-Checker-UA.md) — статичний аналізатор завершуваності (Termination Checker) та детекція гонитв.
* [Kuzmin-Machine-Verification-and-Benchmark-Suite-UA.md](04-verification-and-qa/Kuzmin-Machine-Verification-and-Benchmark-Suite-UA.md) — методологія тестування, еталонні набори трас і бенчмарки.
* [Kuzmin-Machine-TRL-Assessment-Matrix-UA.md](04-verification-and-qa/Kuzmin-Machine-TRL-Assessment-Matrix-UA.md) — офіційний паспорт та матриця оцінки рівнів технологічної готовності (TRL 1–9) за ISO 16290 / Brave1.
* [KUZMIN_MACHINE_TRL_ASSESSMENT_MEMO_UA_v1.0.md](04-verification-and-qa/KUZMIN_MACHINE_TRL_ASSESSMENT_MEMO_UA_v1.0.md) — інженерно-аналітичне мемо оцінки поточної зрілості (TRL 3/4) та програми випробувань.

### [05-applications-and-guides/](05-applications-and-guides/) — Практичне застосування та гайди
* [Kuzmin-Machine-Developers-Guide-UA.md](05-applications-and-guides/Kuzmin-Machine-Developers-Guide-UA.md) — настанова для розробників систем на базі МК.
* [Kuzmin-Machine-Expert-Systems-and-Knowledge-Engineering-UA.md](05-applications-and-guides/Kuzmin-Machine-Expert-Systems-and-Knowledge-Engineering-UA.md) — інженерія знань, Rete/Truth Maintenance та продукційні правила.

### [06-economic-model/](06-economic-model/) — Економічні моделі, TCO та галузеві ніші
* [README.md](06-economic-model/README.md) — зведений науково-економічний аналіз, методологія TCO (ISO 15288 / GAO-20-195G), матриця окупності та порівняння аналогів.
* [Business_Feasibility_Study.md](06-economic-model/Business_Feasibility_Study.md) — комплексне техніко-економічне обґрунтування (ТЕО) проєкту.
* [Business_Development_Plan.md](06-economic-model/Business_Development_Plan.md) — план розвитку бізнесу: від PYNQ-Z1 та НАНУ до залучення інвестицій.
* [commercialization-models-and-patent-strategy.md](06-economic-model/commercialization-models-and-patent-strategy.md) — стратегія патентування (Укрпатент/PCT) та порівняльний аналіз моделей комерціалізації (IP-роялті, Hardware OEM, Cloud HaaS).
* [ukrainian-grants-funding-and-reporting-guide.md](06-economic-model/ukrainian-grants-funding-and-reporting-guide.md) — посібник із грантів в Україні: Brave1, USF, допустимі витрати, бухоблік та звітність.
* [tco_calculator.py](06-economic-model/tco_calculator.py) та [test_tco_calculator.py](06-economic-model/test_tco_calculator.py) — скрипт розрахунку TCO/ROI.
* **Галузеві вертикалі:**
  * [automotive-safety-cybersecurity.md](06-economic-model/automotive-safety-cybersecurity.md) — Automotive (ISO 26262 ASIL D, ISO/SAE 21434).
  * [avionics-safety-critical.md](06-economic-model/avionics-safety-critical.md) — Avionics (DO-178C / DO-254 DAL A, WCET, FADEC).
  * [medicine-biomedical-devices.md](06-economic-model/medicine-biomedical-devices.md) — Medicine (IEC 62304 Class C, імпланти, QDI асинхронні схеми).
  * [martech-realtime-bidding.md](06-economic-model/martech-realtime-bidding.md) — MarTech (OpenRTB 3.0, PCIe FPGA біддери).
  * [logistics-warehouse-coldchain.md](06-economic-model/logistics-warehouse-coldchain.md) — Logistics (ISO 3691-4 AGV/AMR, холодний ланцюг).
  * [miltech-defense-aerospace.md](06-economic-model/miltech-defense-aerospace.md) — MilTech (MIL-STD-882E, етичний замок DoD 3000.09).
  * [gambling-fairness-rng-integrity.md](06-economic-model/gambling-fairness-rng-integrity.md) — Gambling (GLI-11/GLI-19, апаратний аудит ГВЧ).
  * [sports-betting-realtime-risk.md](06-economic-model/sports-betting-realtime-risk.md) — SportsBetting (Live In-Play ризик, ліквідація Latency Arbitrage).

### [07-scientific-opposition/](07-scientific-opposition/) — Наукова опозиція та незалежний аудит
* [SCIENTIFIC_OPPOSITION_REPORT_UA.md](07-scientific-opposition/SCIENTIFIC_OPPOSITION_REPORT_UA.md) — критичний звіт незалежної експертизи F-01...F-10.
* [SCIENTIFIC_OPPOSITION_QUESTIONS_TO_AUTHOR_UA_v1.0.md](07-scientific-opposition/SCIENTIFIC_OPPOSITION_QUESTIONS_TO_AUTHOR_UA_v1.0.md) — формальний опитувальник автору.
* [KUZMIN_MACHINE_APPLICATION_PROSPECTS_MEMO_UA_v1.2.md](07-scientific-opposition/KUZMIN_MACHINE_APPLICATION_PROSPECTS_MEMO_UA_v1.2.md) — мемо аналізу перспектив.
* [opposition-passes/](07-scientific-opposition/opposition-passes/) — робочі проміжні матеріали незалежного аудиту (Opus / Sol).

---

## 3. Швидкий старт (Тести, Парсер, Економічний калькулятор)

### 3.1. Запуск парсера KPOL та еталонних тестів:
```bash
python3 -m unittest 03-engineering-software/test_kpol_reference.py
```

### 3.2. Розрахунок економічної моделі TCO для 8 галузей:
```bash
python3 06-economic-model/tco_calculator.py
```

### 3.3. Тестування формул економічної моделі:
```bash
python3 -m unittest 06-economic-model/test_tco_calculator.py
```

---

## 4. Апаратна реалізація та мовний стек

**Цільова лабораторна платформа** — Digilent PYNQ-Z1 (Zynq-7000 XC7Z020), за наявними записами стенда. На ній уже запускали стандартний PYNQ base overlay, але це не є прошиванням ядра МК.

Поточний FPGA-артефакт — однословний блок транзакційного керування в `02-engineering-hardware/rtl/kpol_txn_gate.sv`. Для нього проходять RTL-тестбенчі та Verilator lint; Yosys має XC7 logic-mapping звіт з оцінкою ресурсів. nextpnr Fmax отримано лише на окремому iCE40 HX8K target і не є виміром затримки на PYNQ. XC7Z020 timing, фінальні ресурси після P&R, реакцію на платі та повну архітектуру ще не вимірювали.

Для RTL-розробки та ранньої перевірки використовуються Icarus Verilog, Verilator і Yosys. Vivado є стандартним вендорним маршрутом синтезу, place-and-route, STA та створення бітстріму для XC7Z020, але не потрібен для попередньої симуляції. Відкритий XC7-маршрут на базі F4PGA/Project X-Ray поки є кандидатом на окрему перевірку, а не підтвердженим способом отримати сумісний PYNQ overlay.

---

## 5. Галузева економіка та ринкові ніші

Параметричний аналіз (5-річний горизонт володіння) доводить, що МК економічно вигідна у сферах із жорсткими вимогами до детермінізму, безпеки або затримки:

| Галузь | Базова технологія | Рішення на МК | Економія TCO |
| :--- | :--- | :--- | :--- |
| **Automotive** | Lockstep ARM Cortex-R52 + AUTOSAR | FPGA Safety Cage | **21.2%** |
| **Avionics** | Двоканальний процесор + DO-178C C | SMT-доведення KPOL | **31.9%** |
| **Medicine** | MCU надмалого споживання + RTOS | Безтактове асинхронне ядро | **28.4%** |
| **MarTech** | 200 хмарних серверів Redis/Flink | 4 сервери + PCIe FPGA МК | **82.1%** |
| **Logistics** | Центральний сервер Wi-Fi арбітражу | Локальні UWB-інтерлоки | **19.7%** |
| **MilTech** | Linux/RTOS SDR + зовнішній HSM | Апаратний замок DoD 3000.09 | **27.3%** |
| **Gambling** | x86 IPC + Linux + GLI-11 софт | CPLD FairPlay Arbiter | **38.6%** |
| **SportsBetting** | Кластер Redis/Kafka + ризик-софт | FPGA Alveo Risk Gate | **66.6%** |

---

## 6. Наукова опозиція та Popperian Red-Teaming

Дослідження Машини Кузьміна ведеться на засадах **критичного раціоналізму Карла Поппера**:
* Кожне теоретичне твердження супроводжується **критерієм спростування (Falsifiable Test)**.
* Матеріали опозиційного аудиту відкриті для спільноти у розділі [`07-scientific-opposition/`](07-scientific-opposition/).
